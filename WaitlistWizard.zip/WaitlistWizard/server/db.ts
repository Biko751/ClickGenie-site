import { drizzle } from 'drizzle-orm/node-postgres';
import { migrate } from 'drizzle-orm/node-postgres/migrator';
import { sql } from 'drizzle-orm';
import pg from 'pg';
import * as schema from '@shared/schema';
import * as fs from 'fs';
import * as path from 'path';
import { nanoid } from 'nanoid';

const { Pool } = pg;

// Create PostgreSQL connection pool with optimized settings
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 5, // Reduced maximum connections to avoid exhausting connection limits
  idleTimeoutMillis: 30000, // How long a client is allowed to remain idle before being closed
  connectionTimeoutMillis: 5000, // Increased timeout for connection availability
  // Reuse or create a new connection if none is available
  allowExitOnIdle: false
});

// Create Drizzle ORM instance
export const db = drizzle(pool, { schema });

// Initialize database function - this will run migrations
export async function initializeDatabase() {
  try {
    // Check if tables exist
    const result = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'users'
      );
    `);
    
    const tablesExist = result.rows[0]?.exists || false;
    
    if (!tablesExist) {
      // Tables don't exist, run initial migrations
      try {
        console.log('Running database migrations...');
        await migrate(db, { migrationsFolder: './drizzle' });
        console.log('Database migrations completed successfully');
        
        // Seed initial data
        await seedInitialData();
      } catch (migrationError) {
        console.error('Migration error:', migrationError);
      }
    } else {
      console.log('Tables already exist, running custom migrations');
      
      // Run custom migrations for schema updates
      await runCustomMigrations();
      
      // Ensure we have an admin user
      await seedInitialData();
    }
    
    return true;
  } catch (error) {
    console.error('Error initializing database:', error);
    return false;
  }
}

// Run custom SQL migrations
async function runCustomMigrations() {
  try {
    // Check if migrations directory exists
    const migrationsDir = path.join(process.cwd(), 'migrations');
    
    if (fs.existsSync(migrationsDir)) {
      const migrations = fs.readdirSync(migrationsDir)
        .filter(file => file.endsWith('.sql'))
        .sort(); // Apply migrations in alphabetical order
      
      for (const migration of migrations) {
        console.log(`Running migration: ${migration}`);
        const sql = fs.readFileSync(path.join(migrationsDir, migration), 'utf8');
        
        try {
          await pool.query(sql);
          console.log(`Migration ${migration} completed successfully`);
        } catch (error) {
          console.error(`Error running migration ${migration}:`, error);
          // Continue with other migrations
        }
      }
    }
  } catch (error) {
    console.error('Error running custom migrations:', error);
  }
}

// Add seed data for development/testing
async function seedInitialData() {
  try {
    // Check if admin user exists
    const adminExists = await db.query.users.findFirst({
      where: (users, { eq }) => eq(users.username, 'stevebiko751'),
    });
    
    // Only seed if admin doesn't exist
    if (!adminExists) {
      console.log('Creating default admin user: Biko751');
      
      try {
        // Try to create admin user with all fields
        // This might fail if the schema hasn't been updated yet
        await db.insert(schema.users).values({
          username: 'stevebiko751',
          password: '354789621@Biko', // This should be hashed in production
          email: 'stevebiko751@gmail.com',
          role: 'admin',
          referralCode: nanoid(8),
          balance: 1000, // Give admin some initial balance
          clicksGiven: 0,
          clicksReceived: 0,
          dailyLoginStreak: 0,
          vipMember: true,
          vipExpiry: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year from now
          active: true,
          createdAt: new Date()
        });
        
        console.log('Admin user created successfully with all fields');
      } catch (fieldError) {
        // If the above fails (e.g., due to missing fields), try with basic fields
        console.warn('Creating admin user with basic fields only, some columns may be missing');
        
        try {
          await db.insert(schema.users).values({
            username: 'stevebiko751',
            password: '354789621@Biko',
            email: 'stevebiko751@gmail.com',
            role: 'admin',
            referralCode: nanoid(8),
            balance: 1000,
            clicksGiven: 0,
            clicksReceived: 0,
            dailyLoginStreak: 0,
            vipMember: true,
            vipExpiry: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)
          });
          
          console.log('Admin user created successfully with basic fields');
        } catch (basicError) {
          console.error('Failed to create admin user with basic fields:', basicError);
          throw basicError;
        }
      }
    }
  } catch (error) {
    console.error('Error seeding initial data:', error);
    // Don't throw here to allow the server to start even if seeding fails
    return false;
  }
  
  return true;
}