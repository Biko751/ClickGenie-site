import Stripe from "stripe";
import { storage } from "./storage";
import { Withdrawal } from "@shared/schema";

// Check for the Stripe secret key
if (!process.env.STRIPE_SECRET_KEY) {
  console.warn('Missing Stripe secret key. Stripe functionality will be mocked.');
}

// Create a Stripe instance
const stripe = process.env.STRIPE_SECRET_KEY 
  ? new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: "2023-10-16" as any })
  : null;

/**
 * Create a payment intent with Stripe
 */
export async function createStripePaymentIntent(amount: number, currency = 'usd') {
  if (!stripe) {
    throw new Error('Stripe is not configured. Please set STRIPE_SECRET_KEY environment variable.');
  }

  // Create a PaymentIntent with the order amount and currency
  const paymentIntent = await stripe.paymentIntents.create({
    amount: Math.round(amount * 100), // Convert to cents
    currency,
  });

  return paymentIntent;
}

/**
 * Process a withdrawal through the appropriate payment method
 */
export async function processWithdrawal(withdrawal: Withdrawal, user: any) {
  try {
    let result: any = null;
    
    // Choose the appropriate processor based on withdrawal method
    switch (withdrawal.method) {
      case 'paypal':
        result = await processPayPalWithdrawal(withdrawal, user);
        break;
      case 'bank':
        result = await processBankWithdrawal(withdrawal, user);
        break;
      case 'crypto':
        result = await processCryptoWithdrawal(withdrawal, user);
        break;
      default:
        throw new Error(`Unsupported withdrawal method: ${withdrawal.method}`);
    }
    
    // Update the withdrawal record
    if (result) {
      await storage.updateWithdrawal(withdrawal.id, {
        status: 'completed',
        gatewayId: result.id,
        gatewayResponse: result,
        processedAt: new Date()
      });
    }
    
    return result;
  } catch (error) {
    console.error('Error processing withdrawal:', error);
    
    // Update the withdrawal with error information
    await storage.updateWithdrawal(withdrawal.id, {
      status: 'failed',
      gatewayResponse: { error: (error as Error).message },
      processedAt: new Date()
    });
    
    throw error;
  }
}

/**
 * Process PayPal withdrawal
 */
async function processPayPalWithdrawal(withdrawal: Withdrawal, user: any) {
  if (!stripe) {
    throw new Error('Stripe is not configured for PayPal transfers.');
  }
  
  // In a real implementation, you would use Stripe to issue a PayPal payout
  // This is a simplified example
  try {
    const transfer = await stripe.transfers.create({
      amount: Math.round(withdrawal.amount * 100),
      currency: 'usd',
      destination: withdrawal.address, // PayPal email address
      description: `ClickGenie withdrawal for ${user.username}`
    });
    
    await storage.updateWithdrawal(withdrawal.id, {
      gatewayId: transfer.id,
      status: 'processing',
      gatewayResponse: transfer
    });
    
    return transfer;
  } catch (error) {
    console.error('PayPal withdrawal error:', error);
    throw error;
  }
}

/**
 * Process bank withdrawal
 */
async function processBankWithdrawal(withdrawal: Withdrawal, user: any) {
  if (!stripe) {
    throw new Error('Stripe is not configured for bank transfers.');
  }
  
  // In a real implementation, you would use Stripe to issue a bank transfer
  // This is a simplified example
  try {
    const transfer = await stripe.transfers.create({
      amount: Math.round(withdrawal.amount * 100),
      currency: 'usd',
      destination: withdrawal.address, // Bank account token
      description: `ClickGenie withdrawal for ${user.username}`
    });
    
    await storage.updateWithdrawal(withdrawal.id, {
      gatewayId: transfer.id,
      status: 'processing',
      gatewayResponse: transfer
    });
    
    return transfer;
  } catch (error) {
    console.error('Bank withdrawal error:', error);
    throw error;
  }
}

/**
 * Process cryptocurrency withdrawal
 */
async function processCryptoWithdrawal(withdrawal: Withdrawal, user: any) {
  if (!stripe) {
    throw new Error('Stripe is not configured for crypto transfers.');
  }
  
  try {
    // Get the crypto network from the withdrawal data
    const gatewayData = withdrawal.gatewayData as { cryptoNetwork?: string };
    const cryptoNetwork = gatewayData?.cryptoNetwork || 'ethereum';
    
    // In a real implementation, you would use a crypto payment processor
    // This is a simplified example using Stripe for demonstration
    const transfer = await stripe.transfers.create({
      amount: Math.round(withdrawal.amount * 100),
      currency: 'usd',
      destination: withdrawal.address, // Crypto wallet address
      description: `ClickGenie ${cryptoNetwork} withdrawal for ${user.username}`
    });
    
    await storage.updateWithdrawal(withdrawal.id, {
      gatewayId: transfer.id,
      status: 'processing',
      gatewayResponse: transfer
    });
    
    return transfer;
  } catch (error) {
    console.error('Crypto withdrawal error:', error);
    throw error;
  }
}

/**
 * Get available payment methods for withdrawals
 */
export async function getPaymentMethods() {
  // Return list of supported payment methods
  return [
    {
      id: 'paypal',
      name: 'PayPal',
      description: 'Withdraw to your PayPal account',
      minAmount: 10,
      processingTime: '1-3 business days',
      fee: '1%',
      icon: 'paypal'
    },
    {
      id: 'bank',
      name: 'Bank Transfer',
      description: 'Withdraw directly to your bank account',
      minAmount: 50,
      processingTime: '3-5 business days',
      fee: '2%',
      icon: 'bank'
    },
    {
      id: 'crypto',
      name: 'Cryptocurrency',
      description: 'Withdraw to your crypto wallet',
      minAmount: 20,
      processingTime: 'Usually within 24 hours',
      fee: '0.5%',
      icon: 'bitcoin',
      networks: [
        { id: 'bitcoin', name: 'Bitcoin (BTC)' },
        { id: 'ethereum', name: 'Ethereum (ETH)' },
        { id: 'usdt', name: 'Tether (USDT)' }
      ]
    }
  ];
}