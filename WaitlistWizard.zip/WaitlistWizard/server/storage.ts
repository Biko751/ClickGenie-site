import { 
  users, type User, type InsertUser,
  offers, type Offer, type InsertOffer,
  clicks, type Click, type InsertClick,
  transactions, type Transaction, type InsertTransaction,
  messages, type Message, type InsertMessage,
  withdrawals, type Withdrawal, type InsertWithdrawal
} from "@shared/schema";
import { nanoid } from "nanoid";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(userId: number, updates: Partial<User>): Promise<User | undefined>;
  updateUserBalance(userId: number, amount: number): Promise<User | undefined>;
  updateUserClickCounts(userId: number, clicksGiven?: number, clicksReceived?: number): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>; // For admin panel
  
  // Offer methods
  getOffer(id: number): Promise<Offer | undefined>;
  getOffers(filters?: { userId?: number, active?: boolean }): Promise<Offer[]>;
  createOffer(offer: InsertOffer): Promise<Offer>;
  updateOffer(id: number, updates: Partial<Offer>): Promise<Offer | undefined>;
  
  // Click methods
  getClicks(filters?: { userId?: number, offerId?: number, verified?: boolean }): Promise<Click[]>;
  createClick(click: InsertClick): Promise<Click>;
  verifyClick(id: number): Promise<Click | undefined>;
  getAllClicks(): Promise<Click[]>; // For admin panel
  
  // Transaction methods
  getTransactions(userId: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getAllTransactions(): Promise<Transaction[]>; // For admin panel
  
  // Message methods
  getMessages(channel: string, limit?: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Withdrawal methods
  getWithdrawals(userId?: number): Promise<Withdrawal[]>;
  getWithdrawal(id: number): Promise<Withdrawal | undefined>;
  createWithdrawal(withdrawal: InsertWithdrawal): Promise<Withdrawal>;
  updateWithdrawal(id: number, updates: Partial<Withdrawal>): Promise<Withdrawal | undefined>;
  
  // Leaderboard methods
  getTopUsers(limit?: number): Promise<User[]>;
  
  // Referral methods
  getUsersByReferrer(referrerId: number): Promise<User[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private offers: Map<number, Offer>;
  private clicks: Map<number, Click>;
  private transactions: Map<number, Transaction>;
  private messages: Map<number, Message>;
  private withdrawals: Map<number, Withdrawal>;
  
  // Auto-incrementing IDs
  private userId: number;
  private offerId: number;
  private clickId: number;
  private transactionId: number;
  private messageId: number;
  private withdrawalId: number;

  constructor() {
    this.users = new Map();
    this.offers = new Map();
    this.clicks = new Map();
    this.transactions = new Map();
    this.messages = new Map();
    this.withdrawals = new Map();
    
    this.userId = 1;
    this.offerId = 1;
    this.clickId = 1;
    this.transactionId = 1;
    this.messageId = 1;
    this.withdrawalId = 1;
    
    // Add some initial data for development
    this.initializeData();
  }

  private initializeData() {
    // Create an admin user with the same credentials as specified in db.ts
    // First, check if user already exists
    const existingAdmin = Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === 'stevebiko751'
    );
    
    if (!existingAdmin) {
      const adminId = this.userId++;
      const now = new Date();
      
      // Create admin user directly to bypass role assignment in createUser method
      const adminUser: User = {
        id: adminId,
        username: "stevebiko751",
        password: "354789621@Biko",
        email: "stevebiko751@gmail.com",
        balance: 1000,
        clicksReceived: 0,
        clicksGiven: 0,
        referralCode: nanoid(8),
        referredBy: null,
        role: "admin", // Explicitly set role to admin
        lastLogin: now,
        dailyLoginStreak: 0,
        lastLoginReward: null,
        vipMember: true,
        vipExpiry: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year from now
        active: true,
        createdAt: now
      };
      
      this.users.set(adminId, adminUser);
      console.log("Admin user created in memory storage:", adminUser.username);
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const referralCode = nanoid(8);
    const now = new Date();
    
    // Create user object with required fields
    // Handle the case where schema changes might be in progress
    try {
      const newUser: User = { 
        ...insertUser, 
        id, 
        balance: 0, 
        clicksReceived: 0, 
        clicksGiven: 0, 
        referralCode,
        referredBy: insertUser.referredBy ?? null,
        role: "user",
        lastLogin: now,
        dailyLoginStreak: 0,
        lastLoginReward: null,
        vipMember: false,
        vipExpiry: null,
        active: true,
        createdAt: now
      };
      this.users.set(id, newUser);
      return newUser;
    } catch (error) {
      // If there's any type error (e.g., schema mismatch), fallback to the basic user fields
      console.warn("Creating user with basic fields only - schema may be outdated");
      const basicUser: any = { 
        ...insertUser, 
        id, 
        balance: 0, 
        clicksReceived: 0, 
        clicksGiven: 0, 
        referralCode,
        referredBy: insertUser.referredBy ?? null,
        role: "user",
        lastLogin: now,
        dailyLoginStreak: 0,
        lastLoginReward: null,
        vipMember: false,
        vipExpiry: null
      };
      this.users.set(id, basicUser);
      return basicUser as User;
    }
  }

  async updateUserBalance(userId: number, amount: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      balance: user.balance + amount 
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async updateUser(userId: number, updates: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async updateUserClickCounts(userId: number, clicksGiven?: number, clicksReceived?: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      clicksGiven: clicksGiven !== undefined ? user.clicksGiven + clicksGiven : user.clicksGiven,
      clicksReceived: clicksReceived !== undefined ? user.clicksReceived + clicksReceived : user.clicksReceived
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Offer methods
  async getOffer(id: number): Promise<Offer | undefined> {
    return this.offers.get(id);
  }

  async getOffers(filters?: { userId?: number; active?: boolean }): Promise<Offer[]> {
    let offers = Array.from(this.offers.values());
    
    if (filters) {
      if (filters.userId !== undefined) {
        offers = offers.filter(offer => offer.userId === filters.userId);
      }
      if (filters.active !== undefined) {
        offers = offers.filter(offer => offer.active === filters.active);
      }
    }
    
    // Sort by newest first
    return offers.sort((a, b) => {
      if (!a.createdAt) return 1;
      if (!b.createdAt) return -1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }

  async createOffer(insertOffer: InsertOffer): Promise<Offer> {
    const id = this.offerId++;
    const now = new Date();
    const offer: Offer = { 
      ...insertOffer, 
      id, 
      active: true, 
      description: insertOffer.description ?? null,
      createdAt: now 
    };
    this.offers.set(id, offer);
    return offer;
  }

  async updateOffer(id: number, updates: Partial<Offer>): Promise<Offer | undefined> {
    const offer = await this.getOffer(id);
    if (!offer) return undefined;
    
    const updatedOffer = { ...offer, ...updates };
    this.offers.set(id, updatedOffer);
    return updatedOffer;
  }

  // Click methods
  async getClicks(filters?: { userId?: number; offerId?: number; verified?: boolean }): Promise<Click[]> {
    let clicks = Array.from(this.clicks.values());
    
    if (filters) {
      if (filters.userId !== undefined) {
        clicks = clicks.filter(click => click.userId === filters.userId);
      }
      if (filters.offerId !== undefined) {
        clicks = clicks.filter(click => click.offerId === filters.offerId);
      }
      if (filters.verified !== undefined) {
        clicks = clicks.filter(click => click.verified === filters.verified);
      }
    }
    
    // Sort by newest first
    return clicks.sort((a, b) => {
      if (!a.createdAt) return 1;
      if (!b.createdAt) return -1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }

  async createClick(insertClick: InsertClick): Promise<Click> {
    const id = this.clickId++;
    const now = new Date();
    const click: Click = { 
      ...insertClick, 
      id, 
      createdAt: now,
      duration: insertClick.duration ?? null,
      verified: insertClick.verified ?? false
    };
    this.clicks.set(id, click);
    return click;
  }

  async verifyClick(id: number): Promise<Click | undefined> {
    const click = this.clicks.get(id);
    if (!click) return undefined;
    
    const verifiedClick = { ...click, verified: true };
    this.clicks.set(id, verifiedClick);
    return verifiedClick;
  }

  // Transaction methods
  async getTransactions(userId: number): Promise<Transaction[]> {
    const transactions = Array.from(this.transactions.values())
      .filter(txn => txn.userId === userId);
    
    // Sort by newest first
    return transactions.sort((a, b) => {
      if (!a.createdAt) return 1;
      if (!b.createdAt) return -1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.transactionId++;
    const now = new Date();
    const transaction: Transaction = {
      ...insertTransaction,
      id,
      createdAt: now,
      status: insertTransaction.status || 'completed'
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  // Message methods
  async getMessages(channel: string, limit = 50): Promise<Message[]> {
    const messages = Array.from(this.messages.values())
      .filter(msg => msg.channel === channel);
    
    // Sort by newest first and limit
    return messages
      .sort((a, b) => {
        if (!a.createdAt) return 1;
        if (!b.createdAt) return -1;
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      })
      .slice(-limit);
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const now = new Date();
    const message: Message = { 
      ...insertMessage, 
      id, 
      createdAt: now,
      channel: insertMessage.channel || 'general'
    };
    this.messages.set(id, message);
    return message;
  }

  // Leaderboard methods
  async getTopUsers(limit = 10): Promise<User[]> {
    return Array.from(this.users.values())
      .sort((a, b) => b.balance - a.balance)
      .slice(0, limit);
  }

  // Referral methods
  async getUsersByReferrer(referrerId: number): Promise<User[]> {
    return Array.from(this.users.values())
      .filter(user => user.referredBy === referrerId);
  }
  
  // Admin methods - added for admin panel
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  async getAllClicks(): Promise<Click[]> {
    return Array.from(this.clicks.values());
  }
  
  async getAllTransactions(): Promise<Transaction[]> {
    return Array.from(this.transactions.values());
  }
  
  // Withdrawal methods
  async getWithdrawals(userId?: number): Promise<Withdrawal[]> {
    let withdrawals = Array.from(this.withdrawals.values());
    
    if (userId !== undefined) {
      withdrawals = withdrawals.filter(withdrawal => withdrawal.userId === userId);
    }
    
    // Sort by newest first
    return withdrawals.sort((a, b) => {
      if (!a.createdAt) return 1;
      if (!b.createdAt) return -1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }
  
  async getWithdrawal(id: number): Promise<Withdrawal | undefined> {
    return this.withdrawals.get(id);
  }
  
  async createWithdrawal(insertWithdrawal: InsertWithdrawal): Promise<Withdrawal> {
    const id = this.withdrawalId++;
    const now = new Date();
    const withdrawal: Withdrawal = { 
      ...insertWithdrawal, 
      id, 
      status: insertWithdrawal.status || 'pending', 
      createdAt: now,
      gatewayId: insertWithdrawal.gatewayId ?? null,
      gatewayResponse: insertWithdrawal.gatewayResponse ?? null,
      gatewayData: insertWithdrawal.gatewayData ?? null,
      processedAt: insertWithdrawal.processedAt ?? null
    };
    this.withdrawals.set(id, withdrawal);
    return withdrawal;
  }
  
  async updateWithdrawal(id: number, updates: Partial<Withdrawal>): Promise<Withdrawal | undefined> {
    const withdrawal = await this.getWithdrawal(id);
    if (!withdrawal) return undefined;
    
    const updatedWithdrawal = { ...withdrawal, ...updates };
    this.withdrawals.set(id, updatedWithdrawal);
    return updatedWithdrawal;
  }
}

import { DatabaseStorage } from './database-storage';

// Choose which storage implementation to use
const isProd = process.env.NODE_ENV === 'production';
let databaseAvailable = false;

// Import pg directly
import pg from 'pg';
const { Pool } = pg;

// Attempt to execute a simple query to test database connection
const testDatabaseConnection = async () => {
  try {
    if (process.env.DATABASE_URL) {
      const pool = new Pool({
        connectionString: process.env.DATABASE_URL,
        connectionTimeoutMillis: 5000, // 5 second timeout
      });
      
      // Try a simple query
      await pool.query('SELECT NOW()');
      await pool.end(); // Close the connection
      console.log('PostgreSQL database connection successful');
      return true;
    }
    return false;
  } catch (error: any) {
    console.error('PostgreSQL database connection failed:', error.message || String(error));
    return false;
  }
};

// We'll initialize with MemStorage for now and potentially switch later
// after database connection is verified
export const storage: IStorage = new MemStorage();

// Try to connect to the database (this runs async in the background)
// If successful, we'll import and use the DatabaseStorage implementation
(async () => {
  try {
    databaseAvailable = await testDatabaseConnection();
    if (databaseAvailable) {
      // Here we would switch to DatabaseStorage
      // storage = new DatabaseStorage();
      console.log('Ready to switch to PostgreSQL storage');
    }
  } catch (error: any) {
    console.error('Error testing database connection:', error.message || String(error));
  }
})();
