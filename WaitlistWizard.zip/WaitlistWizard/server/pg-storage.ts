import { 
  users, type User, type InsertUser,
  offers, type Offer, type InsertOffer,
  clicks, type Click, type InsertClick,
  transactions, type Transaction, type InsertTransaction,
  messages, type Message, type InsertMessage
} from "@shared/schema";
import { IStorage } from "./storage";
import { db } from "./db";
import { eq, and, desc, asc, sql } from "drizzle-orm";
import { nanoid } from "nanoid";

export class PgStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.query.users.findFirst({
      where: eq(users.id, id)
    });
    return result || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.query.users.findFirst({
      where: eq(users.username, username.toLowerCase())
    });
    return result || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const referralCode = nanoid(8);
    const [newUser] = await db.insert(users)
      .values({ 
        ...insertUser, 
        referralCode,
        balance: 0,
        clicksReceived: 0,
        clicksGiven: 0,
        lastLogin: new Date()
      })
      .returning();
    
    return newUser;
  }

  async updateUserBalance(userId: number, amount: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const [updatedUser] = await db.update(users)
      .set({ balance: user.balance + amount })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  async updateUserClickCounts(
    userId: number, 
    clicksGiven?: number, 
    clicksReceived?: number
  ): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updateData: Partial<User> = {};
    
    if (clicksGiven !== undefined) {
      updateData.clicksGiven = user.clicksGiven + clicksGiven;
    }
    
    if (clicksReceived !== undefined) {
      updateData.clicksReceived = user.clicksReceived + clicksReceived;
    }
    
    const [updatedUser] = await db.update(users)
      .set(updateData)
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  // Offer methods
  async getOffer(id: number): Promise<Offer | undefined> {
    const result = await db.query.offers.findFirst({
      where: eq(offers.id, id)
    });
    return result || undefined;
  }

  async getOffers(filters?: { userId?: number, active?: boolean }): Promise<Offer[]> {
    let whereClause = sql`1=1`; // Default true condition
    
    if (filters) {
      if (filters.userId !== undefined) {
        whereClause = sql`${whereClause} AND ${offers.userId} = ${filters.userId}`;
      }
      
      if (filters.active !== undefined) {
        whereClause = sql`${whereClause} AND ${offers.active} = ${filters.active}`;
      }
    }
    
    // Sort by newest first
    const results = await db.select().from(offers)
      .where(whereClause)
      .orderBy(desc(offers.createdAt));
      
    return results;
  }

  async createOffer(insertOffer: InsertOffer): Promise<Offer> {
    const [newOffer] = await db.insert(offers)
      .values({ 
        ...insertOffer, 
        active: true,
        createdAt: new Date()
      })
      .returning();
    
    return newOffer;
  }

  async updateOffer(id: number, updates: Partial<Offer>): Promise<Offer | undefined> {
    const [updatedOffer] = await db.update(offers)
      .set(updates)
      .where(eq(offers.id, id))
      .returning();
    
    return updatedOffer;
  }

  // Click methods
  async getClicks(filters?: { userId?: number, offerId?: number, verified?: boolean }): Promise<Click[]> {
    let whereClause = sql`1=1`; // Default true condition
    
    if (filters) {
      if (filters.userId !== undefined) {
        whereClause = sql`${whereClause} AND ${clicks.userId} = ${filters.userId}`;
      }
      
      if (filters.offerId !== undefined) {
        whereClause = sql`${whereClause} AND ${clicks.offerId} = ${filters.offerId}`;
      }
      
      if (filters.verified !== undefined) {
        whereClause = sql`${whereClause} AND ${clicks.verified} = ${filters.verified}`;
      }
    }
    
    // Sort by newest first
    const results = await db.select().from(clicks)
      .where(whereClause)
      .orderBy(desc(clicks.createdAt));
      
    return results;
  }

  async createClick(insertClick: InsertClick): Promise<Click> {
    const [newClick] = await db.insert(clicks)
      .values({ 
        ...insertClick,
        createdAt: new Date()
      })
      .returning();
    
    return newClick;
  }

  async verifyClick(id: number): Promise<Click | undefined> {
    const [verifiedClick] = await db.update(clicks)
      .set({ verified: true })
      .where(eq(clicks.id, id))
      .returning();
    
    return verifiedClick;
  }

  // Transaction methods
  async getTransactions(userId: number): Promise<Transaction[]> {
    const results = await db.select()
      .from(transactions)
      .where(sql`${transactions.userId} = ${userId}`)
      .orderBy(desc(transactions.createdAt));
    
    return results;
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [newTransaction] = await db.insert(transactions)
      .values({ 
        ...insertTransaction,
        createdAt: new Date()
      })
      .returning();
    
    return newTransaction;
  }

  // Message methods
  async getMessages(channel: string, limit = 50): Promise<Message[]> {
    const results = await db.select()
      .from(messages)
      .where(sql`${messages.channel} = ${channel}`)
      .orderBy(asc(messages.createdAt))
      .limit(limit);
    
    return results;
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages)
      .values({ 
        ...insertMessage,
        createdAt: new Date()
      })
      .returning();
    
    return newMessage;
  }

  // Leaderboard methods
  async getTopUsers(limit = 10): Promise<User[]> {
    const results = await db.select()
      .from(users)
      .orderBy(desc(users.balance))
      .limit(limit);
    
    return results;
  }

  // Referral methods
  async getUsersByReferrer(referrerId: number): Promise<User[]> {
    const results = await db.select()
      .from(users)
      .where(sql`${users.referredBy} = ${referrerId}`);
    
    return results;
  }
}