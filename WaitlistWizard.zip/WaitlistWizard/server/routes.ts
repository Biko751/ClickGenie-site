import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { WebSocketServer } from "ws";
import WebSocket from "ws";
import {
  registerSchema, loginSchema, withdrawSchema,
  insertOfferSchema, insertClickSchema, insertMessageSchema,
  type Withdrawal, type User, type Offer
} from "@shared/schema";
import { ZodError } from "zod";
import { nanoid } from "nanoid";
import { 
  processWithdrawal, 
  getPaymentMethods 
} from "./payments";

// Helper to handle Zod validation
const validateRequest = (schema: any, data: any) => {
  try {
    return { success: true, data: schema.parse(data) };
  } catch (error) {
    if (error instanceof ZodError) {
      return { 
        success: false, 
        error: error.errors.map(e => ({
          path: e.path.join('.'),
          message: e.message
        }))
      };
    }
    return { success: false, error: 'Validation failed' };
  }
};

// Session helper - in a real app, this would be in Redis or another store
const sessions: Record<string, {userId: number, username: string}> = {};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup session middleware
  app.use((req: any, res, next) => {
    const sessionId = req.headers.authorization?.replace('Bearer ', '');
    if (sessionId && sessions[sessionId]) {
      req.user = sessions[sessionId];
    }
    next();
  });
  
  // Auth middleware
  const requireAuth = (req: any, res: Response, next: Function) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Unauthorized' });
    }
    next();
  };
  
  // Admin middleware - checks if user has admin role
  const requireAdmin = async (req: any, res: Response, next: Function) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Unauthorized' });
    }
    
    // Get user details including role
    const user = await storage.getUser(req.user.userId);
    
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied. Admin rights required.' });
    }
    
    // Add user object to the request for convenience
    req.adminUser = user;
    next();
  };

  // Admin API routes
  // Get all users
  app.get('/api/admin/users', requireAdmin, async (req: Request, res: Response) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch users' });
    }
  });

  // Update user
  app.patch('/api/admin/users/:id', requireAdmin, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const { active, vipMember, role } = req.body;
      
      // Only allow specific fields to be updated
      const updates: Partial<User> = {};
      if (active !== undefined) updates.active = active;
      if (vipMember !== undefined) updates.vipMember = vipMember;
      if (role !== undefined) updates.role = role;
      
      // If user becomes VIP, set expiry to 30 days from now
      if (vipMember === true) {
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + 30);
        updates.vipExpiry = expiryDate;
      }
      
      const updatedUser = await storage.updateUser(userId, updates);
      
      if (!updatedUser) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update user' });
    }
  });

  // Modify user balance
  app.post('/api/admin/users/:id/balance', requireAdmin, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const { amount, reason } = req.body;
      
      if (typeof amount !== 'number') {
        return res.status(400).json({ message: 'Amount must be a number' });
      }
      
      if (!reason) {
        return res.status(400).json({ message: 'Reason is required' });
      }
      
      // Update the user's balance
      const updatedUser = await storage.updateUserBalance(userId, amount);
      
      if (!updatedUser) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Create a transaction record
      await storage.createTransaction({
        userId,
        amount,
        type: 'admin',
        description: reason,
        status: 'completed'
      });
      
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: 'Failed to modify balance' });
    }
  });

  // Get all offers
  app.get('/api/admin/offers', requireAdmin, async (req: Request, res: Response) => {
    try {
      const offers = await storage.getOffers();
      res.json(offers);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch offers' });
    }
  });

  // Update offer
  app.patch('/api/admin/offers/:id', requireAdmin, async (req: Request, res: Response) => {
    try {
      const offerId = parseInt(req.params.id);
      const { title, url, rewardAmount, active } = req.body;
      
      // Only allow specific fields to be updated
      const updates: Partial<Offer> = {};
      if (title !== undefined) updates.title = title;
      if (url !== undefined) updates.link = url; // map url to link field in DB
      if (rewardAmount !== undefined) updates.epc = rewardAmount; // map rewardAmount to epc field in DB
      if (active !== undefined) updates.active = active;
      
      const updatedOffer = await storage.updateOffer(offerId, updates);
      
      if (!updatedOffer) {
        return res.status(404).json({ message: 'Offer not found' });
      }
      
      // Broadcast offer update to all connected clients
      await broadcastOfferUpdate(offerId);
      
      res.json(updatedOffer);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update offer' });
    }
  });

  // Delete offer
  app.delete('/api/admin/offers/:id', requireAdmin, async (req: Request, res: Response) => {
    try {
      const offerId = parseInt(req.params.id);
      const offer = await storage.getOffer(offerId);
      
      if (!offer) {
        return res.status(404).json({ message: 'Offer not found' });
      }
      
      // Instead of deleting, just mark it as inactive
      const updatedOffer = await storage.updateOffer(offerId, { active: false });
      
      // Broadcast offer update to all connected clients
      await broadcastOfferUpdate(offerId);
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete offer' });
    }
  });

  // Get all transactions
  app.get('/api/admin/transactions', requireAdmin, async (req: Request, res: Response) => {
    try {
      const transactions = await storage.getAllTransactions();
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch transactions' });
    }
  });

  // Get all withdrawals
  app.get('/api/admin/withdrawals', requireAdmin, async (req: Request, res: Response) => {
    try {
      const withdrawals = await storage.getWithdrawals();
      res.json(withdrawals);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch withdrawals' });
    }
  });

  // Update withdrawal status
  app.patch('/api/admin/withdrawals/:id', requireAdmin, async (req: Request, res: Response) => {
    try {
      const withdrawalId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!['pending', 'completed', 'rejected'].includes(status)) {
        return res.status(400).json({ message: 'Invalid status' });
      }
      
      const withdrawal = await storage.getWithdrawal(withdrawalId);
      
      if (!withdrawal) {
        return res.status(404).json({ message: 'Withdrawal not found' });
      }
      
      // Only allow updating pending withdrawals
      if (withdrawal.status !== 'pending') {
        return res.status(400).json({ message: 'Cannot update a processed withdrawal' });
      }
      
      const updates: Partial<Withdrawal> = {
        status,
        processedAt: new Date()
      };
      
      const updatedWithdrawal = await storage.updateWithdrawal(withdrawalId, updates);
      
      // If the withdrawal is rejected, refund the user's balance
      if (status === 'rejected') {
        const user = await storage.getUser(withdrawal.userId);
        
        if (user) {
          await storage.updateUserBalance(user.id, withdrawal.amount);
          
          // Create a transaction record for the refund
          await storage.createTransaction({
            userId: user.id,
            amount: withdrawal.amount,
            type: 'refund',
            description: 'Withdrawal request rejected - amount refunded',
            status: 'completed'
          });
        }
      }
      
      res.json(updatedWithdrawal);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update withdrawal status' });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);
  
  // Setup WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Handle WebSocket connections
  wss.on('connection', (ws) => {
    console.log('New WebSocket connection established');
    
    // Send current offers when a new client connects
    (async () => {
      try {
        const activeOffers = await storage.getOffers({ active: true });
        // Get user info for each offer
        const offersWithUsers = await Promise.all(activeOffers.map(async (offer) => {
          const user = await storage.getUser(offer.userId);
          return {
            ...offer,
            username: user?.username || 'Unknown'
          };
        }));
        
        ws.send(JSON.stringify({
          type: 'offers_list',
          offers: offersWithUsers
        }));
      } catch (err) {
        console.error('Error sending initial offers:', err);
      }
    })();
    
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Handle different message types
        if (data.type === 'chat') {
          const { channelId, content, sessionId } = data;
          
          // Verify user is authenticated
          if (!sessionId || !sessions[sessionId]) {
            ws.send(JSON.stringify({ 
              type: 'error', 
              error: 'Unauthorized' 
            }));
            return;
          }
          
          const userId = sessions[sessionId].userId;
          const user = await storage.getUser(userId);
          
          if (!user) {
            ws.send(JSON.stringify({ 
              type: 'error', 
              error: 'User not found' 
            }));
            return;
          }
          
          // Create a new message
          const newMessage = await storage.createMessage({
            userId,
            channel: channelId || 'general',
            content
          });
          
          // Broadcast to all connected clients
          wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'chat',
                message: {
                  id: newMessage.id,
                  userId,
                  username: user.username,
                  channel: newMessage.channel,
                  content: newMessage.content,
                  createdAt: newMessage.createdAt
                }
              }));
            }
          });
        } else if (data.type === 'offer_click_start') {
          // User started a click/engagement
          const { offerId, sessionId } = data;
          if (!sessionId || !sessions[sessionId]) {
            ws.send(JSON.stringify({ 
              type: 'error', 
              error: 'Unauthorized' 
            }));
            return;
          }
          
          // Notify only the clicker that the timer has started
          ws.send(JSON.stringify({
            type: 'click_started',
            offerId,
            startTime: new Date().toISOString()
          }));
        } else if (data.type === 'offer_click_complete') {
          // User completed the required time
          const { offerId, sessionId, duration } = data;
          if (!sessionId || !sessions[sessionId]) {
            ws.send(JSON.stringify({ 
              type: 'error', 
              error: 'Unauthorized' 
            }));
            return;
          }
          
          const userId = sessions[sessionId].userId;
          const offer = await storage.getOffer(offerId);
          
          if (!offer) {
            ws.send(JSON.stringify({ 
              type: 'error', 
              error: 'Offer not found' 
            }));
            return;
          }
          
          // Create the click with verified status
          await storage.createClick({
            offerId,
            userId,
            duration,
            verified: true
          });
          
          // Update user click count
          await storage.updateUserClickCounts(userId, 1, 0);
          
          // Update offer owner's stats
          await storage.updateUserClickCounts(offer.userId, 0, 1);
          
          // Add earnings to clicking user
          await storage.updateUserBalance(userId, offer.epc);
          
          // Create transaction record
          await storage.createTransaction({
            userId,
            amount: offer.epc,
            type: 'earning',
            status: 'completed',
            description: `Click earnings for offer: ${offer.title}`
          });
          
          // Get updated user data
          const updatedUser = await storage.getUser(userId);
          
          // Notify the user of successful click
          ws.send(JSON.stringify({
            type: 'click_verified',
            offerId,
            earnings: offer.epc,
            newBalance: updatedUser?.balance || 0
          }));
          
          // Broadcast updated offer data to all clients
          broadcastOfferUpdate(offerId);
        } else if (data.type === 'request_offers') {
          // Client requesting updated offers list
          const activeOffers = await storage.getOffers({ active: true });
          // Get user info for each offer
          const offersWithUsers = await Promise.all(activeOffers.map(async (offer) => {
            const user = await storage.getUser(offer.userId);
            return {
              ...offer,
              username: user?.username || 'Unknown',
              isAdmin: user?.role === 'admin' // Prioritize admin offers
            };
          }));
          
          // Sort offers: admin offers first, then random
          const sortedOffers = offersWithUsers.sort((a, b) => {
            if (a.isAdmin && !b.isAdmin) return -1;
            if (!a.isAdmin && b.isAdmin) return 1;
            return Math.random() - 0.5; // Random sort for non-admin offers
          });
          
          ws.send(JSON.stringify({
            type: 'offers_list',
            offers: sortedOffers
          }));
        }
      } catch (error) {
        console.error('WebSocket error:', error);
        ws.send(JSON.stringify({ 
          type: 'error',
          error: 'Invalid message format'
        }));
      }
    });
  });
  
  // Helper function to broadcast offer updates
  async function broadcastOfferUpdate(offerId: number) {
    try {
      const offer = await storage.getOffer(offerId);
      if (!offer) return;
      
      const user = await storage.getUser(offer.userId);
      
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            type: 'offer_updated',
            offer: {
              ...offer,
              username: user?.username || 'Unknown',
              isAdmin: user?.role === 'admin'
            }
          }));
        }
      });
    } catch (err) {
      console.error('Error broadcasting offer update:', err);
    }
  }

  // API Routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const validation = validateRequest(registerSchema, req.body);
      if (!validation.success) {
        return res.status(400).json({ errors: validation.error });
      }
      
      const { username, password, email, referredBy } = validation.data;
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: 'Username already taken' });
      }
      
      // Create the user
      const newUser = await storage.createUser({
        username,
        password, // In a real app, hash this password!
        email,
        referredBy
      });
      
      // Create a session
      const sessionId = nanoid();
      sessions[sessionId] = { userId: newUser.id, username: newUser.username };
      
      // If user was referred, add bonus to referrer
      if (referredBy) {
        const referrer = await storage.getUser(referredBy);
        if (referrer) {
          await storage.updateUserBalance(referredBy, 5);
          await storage.createTransaction({
            userId: referredBy,
            amount: 5,
            type: 'referral',
            status: 'completed',
            description: `Referral bonus for ${username}`
          });
        }
      }
      
      res.status(201).json({
        user: {
          id: newUser.id,
          username: newUser.username,
          email: newUser.email,
          balance: newUser.balance,
          clicksReceived: newUser.clicksReceived,
          clicksGiven: newUser.clicksGiven,
          referralCode: newUser.referralCode
        },
        sessionId
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({ message: 'Registration failed' });
    }
  });
  
  app.post('/api/auth/login', async (req, res) => {
    try {
      const validation = validateRequest(loginSchema, req.body);
      if (!validation.success) {
        return res.status(400).json({ errors: validation.error });
      }
      
      const { username, password } = validation.data;
      
      // Find the user
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) { // In a real app, use proper password comparison
        return res.status(401).json({ message: 'Invalid username or password' });
      }
      
      // Create a session
      const sessionId = nanoid();
      sessions[sessionId] = { userId: user.id, username: user.username };
      
      // Calculate daily login rewards
      let dailyLoginReward = 0;
      let dailyLoginStreak = user.dailyLoginStreak || 0;
      let rewardMessage = '';
      
      const now = new Date();
      const lastLoginReward = user.lastLoginReward ? new Date(user.lastLoginReward) : null;
      
      // Check if this is a new day for login rewards
      if (!lastLoginReward || 
          (now.getDate() !== lastLoginReward.getDate() || 
           now.getMonth() !== lastLoginReward.getMonth() || 
           now.getFullYear() !== lastLoginReward.getFullYear())) {
        
        // Increment streak only if last login was yesterday, otherwise reset
        if (lastLoginReward) {
          const yesterday = new Date(now);
          yesterday.setDate(yesterday.getDate() - 1);
          
          if (lastLoginReward.getDate() === yesterday.getDate() && 
              lastLoginReward.getMonth() === yesterday.getMonth() && 
              lastLoginReward.getFullYear() === yesterday.getFullYear()) {
            dailyLoginStreak++;
          } else {
            dailyLoginStreak = 1; // Reset streak if not consecutive days
          }
        } else {
          dailyLoginStreak = 1; // First login
        }
        
        // Calculate reward based on streak
        if (dailyLoginStreak <= 5) {
          dailyLoginReward = 0.5 * dailyLoginStreak; // 0.5, 1.0, 1.5, 2.0, 2.5
        } else if (dailyLoginStreak <= 10) {
          dailyLoginReward = 3.0; // $3 reward for days 6-10
        } else if (dailyLoginStreak <= 20) {
          dailyLoginReward = 5.0; // $5 reward for days 11-20
        } else {
          dailyLoginReward = 10.0; // $10 reward for 21+ days
        }
        
        // Update user with reward
        if (dailyLoginReward > 0) {
          await storage.updateUserBalance(user.id, dailyLoginReward);
          
          // Create transaction record for the reward
          await storage.createTransaction({
            userId: user.id,
            amount: dailyLoginReward,
            type: 'reward',
            status: 'completed',
            description: `Daily login reward (Day ${dailyLoginStreak})`
          });
          
          rewardMessage = `You received $${dailyLoginReward.toFixed(2)} for your Day ${dailyLoginStreak} login streak!`;
        }
        
        // Update user's login streak and timestamp
        await storage.updateUser(user.id, {
          dailyLoginStreak,
          lastLoginReward: now
        });
      }
      
      // Get the updated user
      const updatedUser = await storage.getUser(user.id);
      
      if (!updatedUser) {
        return res.status(404).json({ message: 'User not found after update' });
      }
      
      res.status(200).json({
        user: {
          id: updatedUser.id,
          username: updatedUser.username,
          email: updatedUser.email,
          balance: updatedUser.balance,
          clicksReceived: updatedUser.clicksReceived,
          clicksGiven: updatedUser.clicksGiven,
          referralCode: updatedUser.referralCode,
          role: updatedUser.role || 'user',
          lastLogin: updatedUser.lastLogin,
          dailyLoginStreak: updatedUser.dailyLoginStreak || 0,
          vipMember: updatedUser.vipMember || false
        },
        sessionId,
        dailyLoginReward: dailyLoginReward > 0 ? {
          amount: dailyLoginReward,
          streak: dailyLoginStreak,
          message: rewardMessage
        } : null
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Login failed' });
    }
  });
  
  app.post('/api/auth/logout', (req, res) => {
    const sessionId = req.headers.authorization?.replace('Bearer ', '');
    if (sessionId) {
      delete sessions[sessionId];
    }
    res.status(200).json({ message: 'Logged out successfully' });
  });
  
  // User routes
  app.get('/api/user', requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      res.status(200).json({
        id: user.id,
        username: user.username,
        email: user.email,
        balance: user.balance,
        clicksReceived: user.clicksReceived,
        clicksGiven: user.clicksGiven,
        referralCode: user.referralCode,
        lastLogin: user.lastLogin
      });
    } catch (error) {
      console.error('Get user error:', error);
      res.status(500).json({ message: 'Failed to get user data' });
    }
  });
  
  // Offer routes
  app.get('/api/offers', async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const active = req.query.active ? req.query.active === 'true' : undefined;
      
      const offers = await storage.getOffers({ userId, active });
      
      // Get user info for each offer
      const offersWithUsers = await Promise.all(offers.map(async (offer) => {
        const user = await storage.getUser(offer.userId);
        return {
          ...offer,
          username: user?.username || 'Unknown'
        };
      }));
      
      res.status(200).json(offersWithUsers);
    } catch (error) {
      console.error('Get offers error:', error);
      res.status(500).json({ message: 'Failed to get offers' });
    }
  });
  
  app.post('/api/offers', requireAuth, async (req: any, res) => {
    try {
      const validation = validateRequest(insertOfferSchema, { 
        ...req.body, 
        userId: req.user.userId 
      });
      
      if (!validation.success) {
        return res.status(400).json({ errors: validation.error });
      }
      
      const newOffer = await storage.createOffer(validation.data);
      
      res.status(201).json(newOffer);
    } catch (error) {
      console.error('Create offer error:', error);
      res.status(500).json({ message: 'Failed to create offer' });
    }
  });
  
  app.put('/api/offers/:id', requireAuth, async (req: any, res) => {
    try {
      const offerId = parseInt(req.params.id);
      const offer = await storage.getOffer(offerId);
      
      if (!offer) {
        return res.status(404).json({ message: 'Offer not found' });
      }
      
      if (offer.userId !== req.user.userId) {
        return res.status(403).json({ message: 'Not authorized to update this offer' });
      }
      
      const updatedOffer = await storage.updateOffer(offerId, req.body);
      res.status(200).json(updatedOffer);
    } catch (error) {
      console.error('Update offer error:', error);
      res.status(500).json({ message: 'Failed to update offer' });
    }
  });
  
  // Click routes
  app.post('/api/clicks', requireAuth, async (req: any, res) => {
    try {
      const validation = validateRequest(insertClickSchema, {
        ...req.body,
        userId: req.user.userId
      });
      
      if (!validation.success) {
        return res.status(400).json({ errors: validation.error });
      }
      
      const { offerId, duration, verified } = validation.data;
      
      // Get the offer
      const offer = await storage.getOffer(offerId);
      if (!offer) {
        return res.status(404).json({ message: 'Offer not found' });
      }
      
      // Create the click
      const newClick = await storage.createClick({
        offerId,
        userId: req.user.userId,
        duration,
        verified
      });
      
      // If click is verified, update stats and process the earnings
      if (verified) {
        // Update user click count
        await storage.updateUserClickCounts(req.user.userId, 1, 0);
        
        // Update offer owner's stats
        await storage.updateUserClickCounts(offer.userId, 0, 1);
        
        // Add earnings to clicking user
        await storage.updateUserBalance(req.user.userId, offer.epc);
        
        // Create transaction record
        await storage.createTransaction({
          userId: req.user.userId,
          amount: offer.epc,
          type: 'earning',
          status: 'completed',
          description: `Click earnings for offer: ${offer.title}`
        });
      }
      
      res.status(201).json(newClick);
    } catch (error) {
      console.error('Create click error:', error);
      res.status(500).json({ message: 'Failed to create click' });
    }
  });
  
  app.put('/api/clicks/:id/verify', requireAuth, async (req: any, res) => {
    try {
      const clickId = parseInt(req.params.id);
      const click = await storage.verifyClick(clickId);
      
      if (!click) {
        return res.status(404).json({ message: 'Click not found' });
      }
      
      // Get the offer
      const offer = await storage.getOffer(click.offerId);
      if (!offer) {
        return res.status(404).json({ message: 'Offer not found' });
      }
      
      // Update user click count
      await storage.updateUserClickCounts(req.user.userId, 1, 0);
      
      // Update offer owner's stats
      await storage.updateUserClickCounts(offer.userId, 0, 1);
      
      // Add earnings to clicking user
      await storage.updateUserBalance(req.user.userId, offer.epc);
      
      // Create transaction record
      await storage.createTransaction({
        userId: req.user.userId,
        amount: offer.epc,
        type: 'earning',
        status: 'completed',
        description: `Click earnings for offer: ${offer.title}`
      });
      
      res.status(200).json(click);
    } catch (error) {
      console.error('Verify click error:', error);
      res.status(500).json({ message: 'Failed to verify click' });
    }
  });
  
  // Transaction routes
  app.get('/api/transactions', requireAuth, async (req: any, res) => {
    try {
      const transactions = await storage.getTransactions(req.user.userId);
      res.status(200).json(transactions);
    } catch (error) {
      console.error('Get transactions error:', error);
      res.status(500).json({ message: 'Failed to get transactions' });
    }
  });
  
  app.post('/api/withdrawals', requireAuth, async (req: any, res) => {
    try {
      const validation = validateRequest(withdrawSchema, req.body);
      if (!validation.success) {
        return res.status(400).json({ errors: validation.error });
      }
      
      const { amount, method, address, cryptoNetwork } = validation.data;
      
      // Get the user
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Validate withdrawal amount
      if (amount > user.balance) {
        return res.status(400).json({ message: 'Insufficient balance' });
      }
      
      // Apply minimum withdrawal amount based on VIP status
      const minAmount = user.vipMember ? 10 : 50;
      if (amount < minAmount) {
        return res.status(400).json({ 
          message: `Minimum withdrawal amount is $${minAmount}` + 
                  (user.vipMember ? '' : ' (VIP members can withdraw as little as $10)')
        });
      }
      
      // Create transaction record for the withdrawal
      const transaction = await storage.createTransaction({
        userId: req.user.userId,
        amount: -amount,
        type: 'withdrawal',
        status: 'pending',
        description: `Withdrawal via ${method}`
      });
      
      // Create withdrawal record with payment gateway data
      const withdrawal = await storage.createWithdrawal({
        userId: req.user.userId,
        transactionId: transaction.id,
        amount: amount,
        method: method,
        address: address,
        status: 'pending',
        gatewayId: null,
        gatewayResponse: null,
        gatewayData: method === 'crypto' ? { cryptoNetwork } : null,
        processedAt: null
      });
      
      // Update user balance
      await storage.updateUserBalance(req.user.userId, -amount);
      
      // If the withdrawal is for a VIP member, process it immediately
      if (user.vipMember) {
        try {
          await processWithdrawal(withdrawal, user);
          
          // Get the updated withdrawal after processing
          const updatedWithdrawal = await storage.getWithdrawal(withdrawal.id);
          
          // Return the processed withdrawal
          res.status(201).json({
            withdrawal: updatedWithdrawal,
            transaction,
            success: true,
            message: 'Withdrawal processed immediately'
          });
        } catch (error) {
          console.error('VIP withdrawal processing error:', error);
          res.status(201).json({
            withdrawal,
            transaction,
            success: true,
            message: 'Withdrawal request submitted, but processing delayed'
          });
        }
      } else {
        // Regular users get their withdrawals processed later
        res.status(201).json({
          withdrawal,
          transaction,
          success: true,
          message: 'Withdrawal request submitted and will be processed within 24-48 hours'
        });
      }
    } catch (error) {
      console.error('Withdrawal error:', error);
      res.status(500).json({ message: 'Failed to process withdrawal' });
    }
  });
  
  // Get available payment methods
  app.get('/api/payment-methods', async (req, res) => {
    try {
      const methods = await getPaymentMethods();
      res.status(200).json(methods);
    } catch (error) {
      console.error('Error fetching payment methods:', error);
      res.status(500).json({ message: 'Failed to get payment methods' });
    }
  });
  
  // Get user's withdrawal history
  app.get('/api/withdrawals', requireAuth, async (req: any, res) => {
    try {
      const withdrawals = await storage.getWithdrawals(req.user.userId);
      
      // Get related transactions for each withdrawal
      const withdrawalsWithDetails = await Promise.all(
        withdrawals.map(async (withdrawal: Withdrawal) => {
          // Only include non-sensitive gateway information
          const { gatewayResponse, ...safeWithdrawal } = withdrawal;
          
          return {
            ...safeWithdrawal,
            gatewayInfo: gatewayResponse ? {
              status: (gatewayResponse as any)?.status || 'unknown',
              created: (gatewayResponse as any)?.created || null,
              id: withdrawal.gatewayId
            } : null
          };
        })
      );
      
      res.status(200).json(withdrawalsWithDetails);
    } catch (error) {
      console.error('Get withdrawals error:', error);
      res.status(500).json({ message: 'Failed to get withdrawal history' });
    }
  });
  

  
  // Leaderboard route
  app.get('/api/leaderboard', async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const users = await storage.getTopUsers(limit);
      
      // Map to just the fields we need
      const leaderboard = users.map(user => ({
        id: user.id,
        username: user.username,
        balance: user.balance,
        clicksGiven: user.clicksGiven,
        clicksReceived: user.clicksReceived
      }));
      
      res.status(200).json(leaderboard);
    } catch (error) {
      console.error('Leaderboard error:', error);
      res.status(500).json({ message: 'Failed to get leaderboard data' });
    }
  });
  
  // Referral routes
  app.get('/api/referrals', requireAuth, async (req: any, res) => {
    try {
      const referrals = await storage.getUsersByReferrer(req.user.userId);
      
      // Map to just the fields we need
      const mappedReferrals = referrals.map(user => ({
        id: user.id,
        username: user.username,
        lastLogin: user.lastLogin
      }));
      
      res.status(200).json(mappedReferrals);
    } catch (error) {
      console.error('Referrals error:', error);
      res.status(500).json({ message: 'Failed to get referrals data' });
    }
  });
  

  
  // Chat routes
  app.get('/api/chat/:channel', async (req, res) => {
    try {
      const channel = req.params.channel || 'general';
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      
      const messages = await storage.getMessages(channel, limit);
      
      // Get user information for each message
      const enrichedMessages = await Promise.all(messages.map(async (msg) => {
        const user = await storage.getUser(msg.userId);
        return {
          ...msg,
          username: user?.username || 'Unknown'
        };
      }));
      
      res.status(200).json(enrichedMessages);
    } catch (error) {
      console.error('Chat messages error:', error);
      res.status(500).json({ message: 'Failed to get chat messages' });
    }
  });

  // Helper function to ensure admin user exists
  async function ensureAdminUser() {
    try {
      // Check if admin user already exists
      let adminUser = await storage.getUserByUsername('Biko751');
      
      if (!adminUser) {
        console.log('Creating default admin user: Biko751');
        // Create the admin user with specified credentials
        adminUser = await storage.createUser({
          username: 'Biko751',
          password: '354789621@Biko',
          email: 'stevebiko751@gmail.com',
          referredBy: null
        });
        
        // Update user role to admin
        await storage.updateUser(adminUser.id, {
          role: 'admin'
        });
        
        console.log('Admin user created successfully');
      } else if (adminUser.role !== 'admin') {
        // Ensure the user has admin role
        await storage.updateUser(adminUser.id, {
          role: 'admin'
        });
        console.log('Updated existing user to admin role: Biko751');
      }
    } catch (error) {
      console.error('Error ensuring admin user exists:', error);
    }
  }
  
  // Call this on server startup to ensure admin exists
  ensureAdminUser();

  // VIP membership routes
  app.get('/api/vip/status', requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Define benefits based on VIP status
      const benefits = user.vipMember ? [
        'Advanced geo-targeting options',
        'Higher click payouts (2x standard rate)',
        'Priority placement in offer rotations',
        'VIP-only offers access',
        'Reduced minimum withdrawal amount',
        'Same-day withdrawals',
        'Ad-free dashboard experience',
        'Priority customer support'
      ] : null;
      
      res.status(200).json({
        vipMember: user.vipMember || false,
        vipExpiry: user.vipExpiry,
        benefits
      });
    } catch (error) {
      console.error('Get VIP status error:', error);
      res.status(500).json({ message: 'Failed to get VIP status' });
    }
  });
  
  app.post('/api/vip/purchase', requireAuth, async (req: any, res) => {
    try {
      const { plan } = req.body;
      
      if (!plan || !['monthly', 'quarterly', 'yearly'].includes(plan)) {
        return res.status(400).json({ message: 'Invalid plan selected' });
      }
      
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Define plan prices and durations
      const plans = {
        monthly: { price: 19.99, days: 30 },
        quarterly: { price: 49.99, days: 90 },
        yearly: { price: 149.99, days: 365 }
      };
      
      const selectedPlan = plans[plan as keyof typeof plans];
      
      // Check if user has enough balance
      if (user.balance < selectedPlan.price) {
        return res.status(400).json({ 
          message: 'Insufficient balance',
          requiredAmount: selectedPlan.price,
          currentBalance: user.balance
        });
      }
      
      // Deduct balance
      await storage.updateUserBalance(user.id, -selectedPlan.price);
      
      // Create transaction record
      await storage.createTransaction({
        userId: user.id,
        amount: -selectedPlan.price,
        type: 'purchase',
        status: 'completed',
        description: `${plan.charAt(0).toUpperCase() + plan.slice(1)} VIP membership purchase`
      });
      
      // Calculate expiry date
      const now = new Date();
      let expiryDate = new Date(now);
      expiryDate.setDate(now.getDate() + selectedPlan.days);
      
      // If user already has VIP and it hasn't expired, extend from the current expiry
      if (user.vipMember && user.vipExpiry && new Date(user.vipExpiry) > now) {
        expiryDate = new Date(user.vipExpiry);
        expiryDate.setDate(expiryDate.getDate() + selectedPlan.days);
      }
      
      // Update user's VIP status
      await storage.updateUser(user.id, {
        vipMember: true,
        vipExpiry: expiryDate
      });
      
      res.status(200).json({
        success: true,
        vipExpiry: expiryDate,
        plan
      });
    } catch (error) {
      console.error('VIP purchase error:', error);
      res.status(500).json({ message: 'Failed to process VIP membership purchase' });
    }
  });

  // Admin Panel Routes
  
  // Admin User Management
  app.get('/api/admin/users', requireAdmin, async (req: any, res) => {
    try {
      // Get query parameters for filtering and pagination
      const search = req.query.search as string | undefined;
      const page = parseInt(req.query.page as string || '1');
      const limit = parseInt(req.query.limit as string || '20');
      const offset = (page - 1) * limit;
      
      // Get all users - in a real implementation, you would need pagination and filtering
      // For now we'll handle simple search in memory
      let allUsers = await storage.getAllUsers();
      
      // Apply search filter if provided
      if (search) {
        const searchLower = search.toLowerCase();
        allUsers = allUsers.filter(user => 
          user.username.toLowerCase().includes(searchLower) ||
          user.email.toLowerCase().includes(searchLower)
        );
      }
      
      // Apply pagination
      const paginatedUsers = allUsers.slice(offset, offset + limit);
      
      // Return users without sensitive information
      const safeUsers = paginatedUsers.map(user => ({
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        balance: user.balance,
        clicksGiven: user.clicksGiven,
        clicksReceived: user.clicksReceived,
        referralCode: user.referralCode,
        lastLogin: user.lastLogin,
        createdAt: user.createdAt,
        active: user.active !== false, // If not explicitly set to false, consider active
        vipMember: user.vipMember,
        vipExpiry: user.vipExpiry
      }));
      
      res.status(200).json({
        users: safeUsers,
        pagination: {
          total: allUsers.length,
          page,
          limit,
          pages: Math.ceil(allUsers.length / limit)
        }
      });
    } catch (error) {
      console.error('Admin get users error:', error);
      res.status(500).json({ message: 'Failed to get users' });
    }
  });
  
  // Get a single user with detailed information
  app.get('/api/admin/users/:id', requireAdmin, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Get additional user data
      const [clicks, transactions, offers, referrals] = await Promise.all([
        storage.getClicks({ userId }),
        storage.getTransactions(userId),
        storage.getOffers({ userId }),
        storage.getUsersByReferrer(userId)
      ]);
      
      // Return user with related information but without sensitive data
      res.status(200).json({
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role,
          balance: user.balance,
          clicksGiven: user.clicksGiven,
          clicksReceived: user.clicksReceived,
          referralCode: user.referralCode,
          lastLogin: user.lastLogin,
          createdAt: user.createdAt,
          dailyLoginStreak: user.dailyLoginStreak,
          active: user.active !== false,
          vipMember: user.vipMember,
          vipExpiry: user.vipExpiry
        },
        activity: {
          clicks: clicks.length,
          transactions: transactions.length,
          offers: offers.length,
          referrals: referrals.length
        },
        recentActivity: {
          clicks: clicks.slice(0, 5),
          transactions: transactions.slice(0, 5)
        }
      });
    } catch (error) {
      console.error('Admin get user error:', error);
      res.status(500).json({ message: 'Failed to get user details' });
    }
  });
  
  // Update user
  app.patch('/api/admin/users/:id', requireAdmin, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Extract allowed fields to update
      const { 
        username, email, role, balance, active, 
        vipMember, vipExpiry
      } = req.body;
      
      // Validate username uniqueness if changing
      if (username && username !== user.username) {
        const existingUser = await storage.getUserByUsername(username);
        if (existingUser && existingUser.id !== userId) {
          return res.status(400).json({ message: 'Username already taken' });
        }
      }
      
      // Create update object with only the provided fields
      const updates: any = {};
      if (username !== undefined) updates.username = username;
      if (email !== undefined) updates.email = email;
      if (role !== undefined) updates.role = role;
      if (balance !== undefined) {
        // If balance is being updated, create a transaction record
        const balanceDiff = balance - user.balance;
        if (balanceDiff !== 0) {
          await storage.createTransaction({
            userId,
            amount: balanceDiff,
            type: 'admin_adjustment',
            status: 'completed',
            description: `Admin balance adjustment by ${req.adminUser.username}`
          });
        }
        updates.balance = balance;
      }
      if (active !== undefined) updates.active = active;
      if (vipMember !== undefined) updates.vipMember = vipMember;
      if (vipExpiry !== undefined) updates.vipExpiry = vipExpiry;
      
      // Update the user
      const updatedUser = await storage.updateUser(userId, updates);
      
      if (!updatedUser) {
        return res.status(500).json({ message: 'Failed to update user' });
      }
      
      res.status(200).json({
        message: 'User updated successfully',
        user: {
          id: updatedUser.id,
          username: updatedUser.username,
          email: updatedUser.email,
          role: updatedUser.role,
          balance: updatedUser.balance,
          active: updatedUser.active !== false,
          vipMember: updatedUser.vipMember,
          vipExpiry: updatedUser.vipExpiry
        }
      });
    } catch (error) {
      console.error('Admin update user error:', error);
      res.status(500).json({ message: 'Failed to update user' });
    }
  });
  
  // Get user activity
  app.get('/api/admin/users/:id/activity', requireAdmin, async (req: any, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Get user activity data
      const [clicks, transactions] = await Promise.all([
        storage.getClicks({ userId }),
        storage.getTransactions(userId)
      ]);
      
      // Group activity by date for charts
      const activityByDate = new Map();
      
      // Process clicks
      clicks.forEach(click => {
        if (click.createdAt) {
          const date = new Date(click.createdAt).toISOString().split('T')[0];
          if (!activityByDate.has(date)) {
            activityByDate.set(date, { clicks: 0, earnings: 0 });
          }
          activityByDate.get(date).clicks++;
        }
      });
      
      // Process transactions
      transactions.forEach(tx => {
        if (tx.createdAt) {
          const date = new Date(tx.createdAt).toISOString().split('T')[0];
          if (!activityByDate.has(date)) {
            activityByDate.set(date, { clicks: 0, earnings: 0 });
          }
          if (tx.amount > 0 && tx.type === 'earning') {
            activityByDate.get(date).earnings += tx.amount;
          }
        }
      });
      
      // Convert map to array sorted by date
      const activityData = Array.from(activityByDate.entries())
        .map(([date, data]) => ({ date, ...data }))
        .sort((a, b) => a.date.localeCompare(b.date));
      
      res.status(200).json({
        userId,
        username: user.username,
        activityData,
        summary: {
          totalClicks: clicks.length,
          totalEarnings: transactions
            .filter(tx => tx.amount > 0 && tx.type === 'earning')
            .reduce((sum, tx) => sum + tx.amount, 0),
          totalWithdrawals: transactions
            .filter(tx => tx.type === 'withdrawal')
            .reduce((sum, tx) => sum + Math.abs(tx.amount), 0)
        }
      });
    } catch (error) {
      console.error('Admin get user activity error:', error);
      res.status(500).json({ message: 'Failed to get user activity' });
    }
  });
  
  // Admin Offer Management
  app.get('/api/admin/offers', requireAdmin, async (req: any, res) => {
    try {
      // Get query parameters for filtering
      const status = req.query.status as string | undefined;
      const search = req.query.search as string | undefined;
      const page = parseInt(req.query.page as string || '1');
      const limit = parseInt(req.query.limit as string || '20');
      const offset = (page - 1) * limit;
      
      // Get all offers
      let allOffers = await storage.getOffers();
      
      // Apply filters
      if (status === 'active') {
        allOffers = allOffers.filter(offer => offer.active);
      } else if (status === 'inactive') {
        allOffers = allOffers.filter(offer => !offer.active);
      }
      
      if (search) {
        const searchLower = search.toLowerCase();
        allOffers = allOffers.filter(offer => 
          offer.title.toLowerCase().includes(searchLower) ||
          offer.description?.toLowerCase().includes(searchLower) ||
          offer.network.toLowerCase().includes(searchLower)
        );
      }
      
      // Apply pagination
      const paginatedOffers = allOffers.slice(offset, offset + limit);
      
      // Get user info for each offer
      const offersWithUsers = await Promise.all(paginatedOffers.map(async (offer) => {
        const user = await storage.getUser(offer.userId);
        const clicks = await storage.getClicks({ offerId: offer.id });
        
        return {
          ...offer,
          username: user?.username || 'Unknown',
          clicksCount: clicks.length,
          verifiedClicksCount: clicks.filter(c => c.verified).length
        };
      }));
      
      res.status(200).json({
        offers: offersWithUsers,
        pagination: {
          total: allOffers.length,
          page,
          limit,
          pages: Math.ceil(allOffers.length / limit)
        }
      });
    } catch (error) {
      console.error('Admin get offers error:', error);
      res.status(500).json({ message: 'Failed to get offers' });
    }
  });
  
  // Create admin offer
  app.post('/api/admin/offers', requireAdmin, async (req: any, res) => {
    try {
      const validation = validateRequest(insertOfferSchema, req.body);
      if (!validation.success) {
        return res.status(400).json({ errors: validation.error });
      }
      
      // Set userId to the admin's userId
      const offerData = {
        ...validation.data,
        userId: req.adminUser.id
      };
      
      const newOffer = await storage.createOffer(offerData);
      
      res.status(201).json({
        message: 'Offer created successfully',
        offer: newOffer
      });
    } catch (error) {
      console.error('Admin create offer error:', error);
      res.status(500).json({ message: 'Failed to create offer' });
    }
  });
  
  // Update offer
  app.patch('/api/admin/offers/:id', requireAdmin, async (req: any, res) => {
    try {
      const offerId = parseInt(req.params.id);
      const offer = await storage.getOffer(offerId);
      
      if (!offer) {
        return res.status(404).json({ message: 'Offer not found' });
      }
      
      // Extract fields to update
      const { 
        title, link, network, countries, epc,
        maxClicksPerDay, description, active 
      } = req.body;
      
      // Create update object with only the provided fields
      const updates: any = {};
      if (title !== undefined) updates.title = title;
      if (link !== undefined) updates.link = link;
      if (network !== undefined) updates.network = network;
      if (countries !== undefined) updates.countries = countries;
      if (epc !== undefined) updates.epc = epc;
      if (maxClicksPerDay !== undefined) updates.maxClicksPerDay = maxClicksPerDay;
      if (description !== undefined) updates.description = description;
      if (active !== undefined) updates.active = active;
      
      // Update the offer
      const updatedOffer = await storage.updateOffer(offerId, updates);
      
      if (!updatedOffer) {
        return res.status(500).json({ message: 'Failed to update offer' });
      }
      
      // Broadcast update to all connected clients
      await broadcastOfferUpdate(offerId);
      
      res.status(200).json({
        message: 'Offer updated successfully',
        offer: updatedOffer
      });
    } catch (error) {
      console.error('Admin update offer error:', error);
      res.status(500).json({ message: 'Failed to update offer' });
    }
  });
  
  // Delete offer
  app.delete('/api/admin/offers/:id', requireAdmin, async (req: any, res) => {
    try {
      const offerId = parseInt(req.params.id);
      const offer = await storage.getOffer(offerId);
      
      if (!offer) {
        return res.status(404).json({ message: 'Offer not found' });
      }
      
      // In this implementation, we'll set active to false instead of actually deleting
      const updatedOffer = await storage.updateOffer(offerId, { active: false });
      
      if (!updatedOffer) {
        return res.status(500).json({ message: 'Failed to delete offer' });
      }
      
      // Broadcast update to all connected clients
      await broadcastOfferUpdate(offerId);
      
      res.status(200).json({
        message: 'Offer deleted successfully'
      });
    } catch (error) {
      console.error('Admin delete offer error:', error);
      res.status(500).json({ message: 'Failed to delete offer' });
    }
  });
  
  // Get offer performance
  app.get('/api/admin/offers/:id/performance', requireAdmin, async (req: any, res) => {
    try {
      const offerId = parseInt(req.params.id);
      const offer = await storage.getOffer(offerId);
      
      if (!offer) {
        return res.status(404).json({ message: 'Offer not found' });
      }
      
      // Get clicks for this offer
      const clicks = await storage.getClicks({ offerId });
      
      // Create performance statistics
      const totalClicks = clicks.length;
      const verifiedClicks = clicks.filter(c => c.verified).length;
      const conversionRate = totalClicks > 0 ? (verifiedClicks / totalClicks) * 100 : 0;
      const totalPayout = verifiedClicks * offer.epc;
      
      // Group clicks by date for chart data
      const clicksByDate = new Map();
      
      clicks.forEach(click => {
        if (click.createdAt) {
          const date = new Date(click.createdAt).toISOString().split('T')[0];
          if (!clicksByDate.has(date)) {
            clicksByDate.set(date, { total: 0, verified: 0 });
          }
          clicksByDate.get(date).total++;
          if (click.verified) {
            clicksByDate.get(date).verified++;
          }
        }
      });
      
      // Convert map to array sorted by date
      const chartData = Array.from(clicksByDate.entries())
        .map(([date, data]) => ({ date, ...data }))
        .sort((a, b) => a.date.localeCompare(b.date));
      
      res.status(200).json({
        offer: {
          id: offer.id,
          title: offer.title,
          network: offer.network,
          epc: offer.epc,
          active: offer.active
        },
        performance: {
          totalClicks,
          verifiedClicks,
          conversionRate,
          totalPayout
        },
        chartData
      });
    } catch (error) {
      console.error('Admin get offer performance error:', error);
      res.status(500).json({ message: 'Failed to get offer performance' });
    }
  });
  
  // Admin Dashboard Stats
  app.get('/api/admin/dashboard', requireAdmin, async (req: any, res) => {
    try {
      // Get system-wide statistics
      const [users, offers, clicks, transactions, withdrawals] = await Promise.all([
        storage.getAllUsers(),
        storage.getOffers(),
        storage.getAllClicks(),
        storage.getAllTransactions(),
        storage.getWithdrawals()
      ]);
      
      // Calculate summary stats
      const totalUsers = users.length;
      const activeUsers = users.filter(u => 
        u.lastLogin && 
        new Date(u.lastLogin).getTime() > Date.now() - (30 * 24 * 60 * 60 * 1000) // Active in last 30 days
      ).length;
      
      const totalOffers = offers.length;
      const activeOffers = offers.filter(o => o.active).length;
      
      const totalClicks = clicks.length;
      const verifiedClicks = clicks.filter(c => c.verified).length;
      
      // Activity in the last 24 hours
      const last24Hours = new Date(Date.now() - (24 * 60 * 60 * 1000)).getTime();
      const clicksLast24h = clicks.filter(c => 
        c.createdAt && new Date(c.createdAt).getTime() > last24Hours
      ).length;
      
      const newUsersLast24h = users.filter(u => 
        u.createdAt && new Date(u.createdAt).getTime() > last24Hours
      ).length;
      
      // Financial stats
      const totalEarnings = transactions
        .filter(t => t.type === 'earning')
        .reduce((sum, t) => sum + t.amount, 0);
      
      const totalWithdrawals = withdrawals
        .filter(w => w.status === 'completed')
        .reduce((sum, w) => sum + w.amount, 0);
      
      const pendingWithdrawals = withdrawals
        .filter(w => w.status === 'pending')
        .reduce((sum, w) => sum + w.amount, 0);
      
      // Get top users by earnings
      const topUsers = users
        .sort((a, b) => b.balance - a.balance)
        .slice(0, 5)
        .map(u => ({
          id: u.id,
          username: u.username,
          balance: u.balance,
          clicksGiven: u.clicksGiven
        }));
      
      // Get top offers by clicks
      const offerClickCounts = new Map();
      clicks.forEach(click => {
        const offerId = click.offerId;
        offerClickCounts.set(offerId, (offerClickCounts.get(offerId) || 0) + 1);
      });
      
      // Convert Map to array before processing
      const offerClickCountsArray = Array.from(offerClickCounts.entries());
      
      const topOffers = await Promise.all(
        offerClickCountsArray
          .sort((a, b) => b[1] - a[1])
          .slice(0, 5)
          .map(async ([offerId, clickCount]) => {
            const offer = await storage.getOffer(offerId);
            return offer ? {
              id: offer.id,
              title: offer.title,
              clickCount,
              epc: offer.epc,
              totalPayout: clickCount * offer.epc
            } : null;
          })
      );
      
      res.status(200).json({
        userStats: {
          totalUsers,
          activeUsers,
          newUsersLast24h
        },
        offerStats: {
          totalOffers,
          activeOffers
        },
        engagementStats: {
          totalClicks,
          verifiedClicks,
          clicksLast24h,
          conversionRate: totalClicks > 0 ? (verifiedClicks / totalClicks) * 100 : 0
        },
        financialStats: {
          totalEarnings,
          totalWithdrawals,
          pendingWithdrawals,
          platformBalance: totalEarnings - totalWithdrawals
        },
        topUsers: topUsers.filter(Boolean),
        topOffers: topOffers.filter(Boolean)
      });
    } catch (error) {
      console.error('Admin dashboard error:', error);
      res.status(500).json({ message: 'Failed to get dashboard data' });
    }
  });
  
  // Admin Withdrawal Management
  app.get('/api/admin/withdrawals', requireAdmin, async (req: any, res) => {
    try {
      // Get query parameters for filtering
      const status = req.query.status as string | undefined;
      const page = parseInt(req.query.page as string || '1');
      const limit = parseInt(req.query.limit as string || '20');
      const offset = (page - 1) * limit;
      
      // Get all withdrawals
      let allWithdrawals = await storage.getWithdrawals();
      
      // Apply status filter if provided
      if (status) {
        allWithdrawals = allWithdrawals.filter(w => w.status === status);
      }
      
      // Sort by created date, newest first
      allWithdrawals.sort((a, b) => {
        if (!a.createdAt) return 1;
        if (!b.createdAt) return -1;
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
      
      // Apply pagination
      const paginatedWithdrawals = allWithdrawals.slice(offset, offset + limit);
      
      // Get user info for each withdrawal
      const withdrawalsWithUsers = await Promise.all(paginatedWithdrawals.map(async (withdrawal) => {
        const user = await storage.getUser(withdrawal.userId);
        
        return {
          ...withdrawal,
          username: user?.username || 'Unknown',
          email: user?.email || 'Unknown'
        };
      }));
      
      res.status(200).json({
        withdrawals: withdrawalsWithUsers,
        pagination: {
          total: allWithdrawals.length,
          page,
          limit,
          pages: Math.ceil(allWithdrawals.length / limit)
        },
        summary: {
          pending: allWithdrawals.filter(w => w.status === 'pending').length,
          processing: allWithdrawals.filter(w => w.status === 'processing').length,
          completed: allWithdrawals.filter(w => w.status === 'completed').length,
          failed: allWithdrawals.filter(w => w.status === 'failed').length
        }
      });
    } catch (error) {
      console.error('Admin get withdrawals error:', error);
      res.status(500).json({ message: 'Failed to get withdrawals' });
    }
  });
  
  // Process withdrawal
  app.post('/api/admin/withdrawals/:id/process', requireAdmin, async (req: any, res) => {
    try {
      const withdrawalId = parseInt(req.params.id);
      const withdrawal = await storage.getWithdrawal(withdrawalId);
      
      if (!withdrawal) {
        return res.status(404).json({ message: 'Withdrawal not found' });
      }
      
      if (withdrawal.status !== 'pending') {
        return res.status(400).json({ 
          message: `Cannot process withdrawal with status: ${withdrawal.status}` 
        });
      }
      
      const user = await storage.getUser(withdrawal.userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Process the withdrawal
      await processWithdrawal(withdrawal, user);
      
      // Get updated withdrawal
      const updatedWithdrawal = await storage.getWithdrawal(withdrawalId);
      
      res.status(200).json({
        message: 'Withdrawal processed successfully',
        withdrawal: updatedWithdrawal
      });
    } catch (error) {
      console.error('Admin process withdrawal error:', error);
      res.status(500).json({ 
        message: 'Failed to process withdrawal',
        error: (error as Error).message
      });
    }
  });
  
  // Approve or reject withdrawal
  app.post('/api/admin/withdrawals/:id/status', requireAdmin, async (req: any, res) => {
    try {
      const withdrawalId = parseInt(req.params.id);
      const { status, reason } = req.body;
      
      if (!status || !['approved', 'rejected'].includes(status)) {
        return res.status(400).json({ message: 'Invalid status. Must be "approved" or "rejected".' });
      }
      
      const withdrawal = await storage.getWithdrawal(withdrawalId);
      
      if (!withdrawal) {
        return res.status(404).json({ message: 'Withdrawal not found' });
      }
      
      if (withdrawal.status !== 'pending') {
        return res.status(400).json({ 
          message: `Cannot update withdrawal with status: ${withdrawal.status}` 
        });
      }
      
      const user = await storage.getUser(withdrawal.userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      if (status === 'approved') {
        // Update status to processing
        await storage.updateWithdrawal(withdrawalId, { 
          status: 'processing',
          gatewayResponse: { 
            adminApproved: true,
            approvedBy: req.adminUser.username,
            approvedAt: new Date().toISOString()
          }
        });
        
        // Process the withdrawal
        await processWithdrawal(withdrawal, user);
      } else {
        // Rejected - refund the amount to user's balance
        await storage.updateUserBalance(user.id, withdrawal.amount);
        
        // Create transaction record for the refund
        await storage.createTransaction({
          userId: user.id,
          amount: withdrawal.amount,
          type: 'refund',
          status: 'completed',
          description: `Refund for rejected withdrawal (#${withdrawal.id})`
        });
        
        // Update withdrawal status
        await storage.updateWithdrawal(withdrawalId, { 
          status: 'rejected',
          gatewayResponse: { 
            adminRejected: true,
            rejectedBy: req.adminUser.username,
            rejectedAt: new Date().toISOString(),
            reason: reason || 'Rejected by admin'
          },
          processedAt: new Date()
        });
      }
      
      // Get updated withdrawal
      const updatedWithdrawal = await storage.getWithdrawal(withdrawalId);
      
      res.status(200).json({
        message: `Withdrawal ${status} successfully`,
        withdrawal: updatedWithdrawal
      });
    } catch (error) {
      console.error('Admin update withdrawal status error:', error);
      res.status(500).json({ 
        message: 'Failed to update withdrawal status',
        error: (error as Error).message
      });
    }
  });
  
  // Admin Site Settings
  app.get('/api/admin/settings', requireAdmin, async (req: any, res) => {
    try {
      // In a real app, you would get these from a database
      // For now, we'll return some default settings
      res.status(200).json({
        general: {
          siteName: 'ClickGenie',
          siteDescription: 'CPA click exchange platform enabling users to earn rewards',
          maintenance: false
        },
        earnings: {
          minimumWithdrawal: 50,
          vipMinimumWithdrawal: 10,
          referralBonus: 5
        },
        offers: {
          defaultEpc: 0.25,
          maxEpc: 2.0,
          minEpc: 0.1,
          requiredSeconds: 120
        }
      });
    } catch (error) {
      console.error('Admin get settings error:', error);
      res.status(500).json({ message: 'Failed to get settings' });
    }
  });
  
  // Update site settings
  app.patch('/api/admin/settings', requireAdmin, async (req: any, res) => {
    try {
      // In a real app, you would update these in a database
      // For this example, we'll just return the submitted settings
      const { general, earnings, offers } = req.body;
      
      res.status(200).json({
        message: 'Settings updated successfully',
        settings: {
          general,
          earnings,
          offers
        }
      });
    } catch (error) {
      console.error('Admin update settings error:', error);
      res.status(500).json({ message: 'Failed to update settings' });
    }
  });
  
  // Get system logs/notifications
  app.get('/api/admin/logs', requireAdmin, async (req: any, res) => {
    try {
      // In a real app, you would get these from a database
      // For this example, we'll return some mock logs
      const logs = [
        { 
          id: 1, 
          type: 'info', 
          message: 'System started', 
          timestamp: new Date(Date.now() - 3600000).toISOString() 
        },
        { 
          id: 2, 
          type: 'user', 
          message: 'New user registered: user123', 
          timestamp: new Date(Date.now() - 1800000).toISOString() 
        },
        { 
          id: 3, 
          type: 'payment', 
          message: 'Withdrawal processed: $100', 
          timestamp: new Date(Date.now() - 900000).toISOString() 
        },
        { 
          id: 4, 
          type: 'error', 
          message: 'Payment gateway connection error', 
          timestamp: new Date(Date.now() - 300000).toISOString() 
        }
      ];
      
      res.status(200).json({ logs });
    } catch (error) {
      console.error('Admin get logs error:', error);
      res.status(500).json({ message: 'Failed to get logs' });
    }
  });
  
  return httpServer;
}
