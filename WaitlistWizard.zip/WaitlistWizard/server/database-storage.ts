import { 
  users, type User, type InsertUser,
  offers, type Offer, type InsertOffer,
  clicks, type Click, type InsertClick,
  transactions, type Transaction, type InsertTransaction,
  messages, type Message, type InsertMessage,
  withdrawals, type Withdrawal, type InsertWithdrawal
} from "@shared/schema";
import { IStorage } from "./storage";
import { db } from "./db";
import { eq, and, desc, asc, sql } from "drizzle-orm";
import { nanoid } from "nanoid";

export class DatabaseStorage implements IStorage {
  // Simple in-memory cache for frequently accessed data
  private userCache: Map<number, { data: User, timestamp: number }>;
  private offerCache: Map<number, { data: Offer, timestamp: number }>;
  private cacheTTL = 1000 * 60 * 5; // 5 minutes cache TTL
  
  constructor() {
    this.userCache = new Map();
    this.offerCache = new Map();
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    // Check cache first
    const cachedUser = this.userCache.get(id);
    const now = Date.now();
    
    if (cachedUser && (now - cachedUser.timestamp < this.cacheTTL)) {
      return cachedUser.data;
    }
    
    // If not in cache or expired, fetch from DB
    const [user] = await db.select().from(users).where(eq(users.id, id));
    
    // Cache the result if found
    if (user) {
      this.userCache.set(id, { data: user, timestamp: now });
    }
    
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const generatedReferralCode = nanoid(8);
    const userData = {
      ...insertUser,
      referralCode: generatedReferralCode,
      referredBy: insertUser.referredBy ?? null,
      balance: 0,
      clicksReceived: 0,
      clicksGiven: 0,
      lastLogin: new Date()
    };
    
    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
      
    return user;
  }

  async updateUser(userId: number, updates: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const [updatedUser] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, userId))
      .returning();
    
    // Update cache with the new user data
    if (updatedUser) {
      this.userCache.set(userId, { data: updatedUser, timestamp: Date.now() });
    } else {
      // If update failed, remove from cache
      this.userCache.delete(userId);
    }
    
    return updatedUser;
  }

  async updateUserBalance(userId: number, amount: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const [updatedUser] = await db
      .update(users)
      .set({ balance: user.balance + amount })
      .where(eq(users.id, userId))
      .returning();
    
    // Update cache with the new user data
    if (updatedUser) {
      this.userCache.set(userId, { data: updatedUser, timestamp: Date.now() });
    } else {
      // If update failed, remove from cache
      this.userCache.delete(userId);
    }
    
    return updatedUser;
  }

  async updateUserClickCounts(
    userId: number, 
    clicksGiven?: number, 
    clicksReceived?: number
  ): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updateData: Partial<User> = {};
    
    if (clicksGiven !== undefined) {
      updateData.clicksGiven = user.clicksGiven + clicksGiven;
    }
    
    if (clicksReceived !== undefined) {
      updateData.clicksReceived = user.clicksReceived + clicksReceived;
    }
    
    updateData.lastLogin = new Date();
    
    const [updatedUser] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, userId))
      .returning();
    
    // Update cache with the new user data
    if (updatedUser) {
      this.userCache.set(userId, { data: updatedUser, timestamp: Date.now() });
    } else {
      // If update failed, remove from cache
      this.userCache.delete(userId);
    }
    
    return updatedUser;
  }

  // Offer methods
  async getOffer(id: number): Promise<Offer | undefined> {
    // Check cache first
    const cachedOffer = this.offerCache.get(id);
    const now = Date.now();
    
    if (cachedOffer && (now - cachedOffer.timestamp < this.cacheTTL)) {
      return cachedOffer.data;
    }
    
    // If not in cache or expired, fetch from DB
    const [offer] = await db.select().from(offers).where(eq(offers.id, id));
    
    // Cache the result if found
    if (offer) {
      this.offerCache.set(id, { data: offer, timestamp: now });
    }
    
    return offer || undefined;
  }

  async getOffers(filters?: { userId?: number, active?: boolean }): Promise<Offer[]> {
    // Create an array to store where conditions
    const conditions = [];
    
    // Add userId condition if provided
    if (filters?.userId !== undefined) {
      conditions.push(eq(offers.userId, filters.userId));
    }
    
    // Add active condition if provided
    if (filters?.active !== undefined) {
      conditions.push(eq(offers.active, filters.active));
    }
    
    // If we have conditions, use and() to combine them
    const whereCondition = conditions.length > 0 
      ? conditions.length === 1 
        ? conditions[0] 
        : and(...conditions)
      : undefined;
    
    // Execute the query with the conditions
    return db.select()
      .from(offers)
      .where(whereCondition)
      .orderBy(desc(offers.createdAt));
  }

  async createOffer(insertOffer: InsertOffer): Promise<Offer> {
    const offerData = {
      ...insertOffer,
      active: true,
      description: insertOffer.description ?? null
    };
    
    const [offer] = await db
      .insert(offers)
      .values(offerData)
      .returning();
    
    return offer;
  }

  async updateOffer(id: number, updates: Partial<Offer>): Promise<Offer | undefined> {
    const [updatedOffer] = await db
      .update(offers)
      .set(updates)
      .where(eq(offers.id, id))
      .returning();
    
    // Update cache with the new offer data
    if (updatedOffer) {
      this.offerCache.set(id, { data: updatedOffer, timestamp: Date.now() });
    } else {
      // If update failed, remove from cache
      this.offerCache.delete(id);
    }
    
    return updatedOffer;
  }

  // Click methods
  async getClicks(filters?: { userId?: number, offerId?: number, verified?: boolean }): Promise<Click[]> {
    // Create an array to store where conditions
    const conditions = [];
    
    // Add userId condition if provided
    if (filters?.userId !== undefined) {
      conditions.push(eq(clicks.userId, filters.userId));
    }
    
    // Add offerId condition if provided
    if (filters?.offerId !== undefined) {
      conditions.push(eq(clicks.offerId, filters.offerId));
    }
    
    // Add verified condition if provided
    if (filters?.verified !== undefined) {
      conditions.push(eq(clicks.verified, filters.verified));
    }
    
    // If we have conditions, use and() to combine them
    const whereCondition = conditions.length > 0 
      ? conditions.length === 1 
        ? conditions[0] 
        : and(...conditions)
      : undefined;
    
    // Execute the query with the conditions
    return db.select()
      .from(clicks)
      .where(whereCondition)
      .orderBy(desc(clicks.createdAt));
  }

  async createClick(insertClick: InsertClick): Promise<Click> {
    // Make sure verified is set to false if not explicitly provided
    const clickData = {
      ...insertClick,
      verified: insertClick.verified ?? false,
      duration: insertClick.duration ?? null
    };
    
    const [click] = await db
      .insert(clicks)
      .values(clickData)
      .returning();
    
    return click;
  }

  async verifyClick(id: number): Promise<Click | undefined> {
    const [verifiedClick] = await db
      .update(clicks)
      .set({ verified: true })
      .where(eq(clicks.id, id))
      .returning();
    
    return verifiedClick;
  }

  // Transaction methods
  async getTransactions(userId: number): Promise<Transaction[]> {
    const results = await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt));
    
    return results;
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    // Make sure status is set if not explicitly provided
    const transactionData = {
      ...insertTransaction,
      status: insertTransaction.status ?? "completed"
    };
    
    const [transaction] = await db
      .insert(transactions)
      .values(transactionData)
      .returning();
    
    return transaction;
  }

  // Message methods
  async getMessages(channel: string, limit = 50): Promise<Message[]> {
    const results = await db
      .select()
      .from(messages)
      .where(eq(messages.channel, channel))
      .orderBy(asc(messages.createdAt))
      .limit(limit);
    
    return results;
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    // Make sure the channel is set if not provided
    const messageData = {
      ...insertMessage,
      channel: insertMessage.channel ?? "general"
    };
    
    const [message] = await db
      .insert(messages)
      .values(messageData)
      .returning();
    
    return message;
  }

  // Leaderboard methods
  async getTopUsers(limit = 10): Promise<User[]> {
    const results = await db
      .select()
      .from(users)
      .orderBy(desc(users.balance))
      .limit(limit);
    
    return results;
  }

  // Referral methods
  async getUsersByReferrer(referrerId: number): Promise<User[]> {
    const results = await db
      .select()
      .from(users)
      .where(eq(users.referredBy, referrerId));
    
    return results;
  }

  // Withdrawal methods
  async getWithdrawals(userId?: number): Promise<Withdrawal[]> {
    const conditions = userId ? eq(withdrawals.userId, userId) : undefined;
    
    const results = await db
      .select()
      .from(withdrawals)
      .where(conditions)
      .orderBy(desc(withdrawals.createdAt));
    
    return results;
  }

  async getWithdrawal(id: number): Promise<Withdrawal | undefined> {
    const [withdrawal] = await db
      .select()
      .from(withdrawals)
      .where(eq(withdrawals.id, id));
    
    return withdrawal || undefined;
  }

  async createWithdrawal(insertWithdrawal: InsertWithdrawal): Promise<Withdrawal> {
    const withdrawalData = {
      ...insertWithdrawal,
      status: insertWithdrawal.status || 'pending',
      gatewayData: insertWithdrawal.gatewayData || null,
      gatewayResponse: insertWithdrawal.gatewayResponse || null,
      processedAt: insertWithdrawal.processedAt || null
    };
    
    const [withdrawal] = await db
      .insert(withdrawals)
      .values(withdrawalData)
      .returning();
    
    return withdrawal;
  }

  async updateWithdrawal(id: number, updates: Partial<Withdrawal>): Promise<Withdrawal | undefined> {
    const [updatedWithdrawal] = await db
      .update(withdrawals)
      .set(updates)
      .where(eq(withdrawals.id, id))
      .returning();
    
    return updatedWithdrawal;
  }
}