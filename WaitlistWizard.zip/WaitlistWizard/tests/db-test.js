// Simple database test
import { db, initializeDatabase } from '../server/db.js';

async function testDatabase() {
  try {
    console.log('Testing database connection...');
    
    // Initialize database (run migrations and seed data)
    const initialized = await initializeDatabase();
    if (!initialized) {
      throw new Error('Failed to initialize database');
    }
    
    // Try to query users table
    const users = await db.query.users.findMany();
    console.log(`Found ${users.length} users:`);
    console.log(users);
    
    console.log('Database test completed successfully');
  } catch (error) {
    console.error('Database test failed:', error);
  }
}

testDatabase();