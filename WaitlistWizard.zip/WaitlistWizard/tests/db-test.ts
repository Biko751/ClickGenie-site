// Test the database connection
import { db, initializeDatabase } from '../server/db';

async function testDb() {
  try {
    console.log('Testing database connection...');
    
    // Initialize database
    await initializeDatabase();
    
    // Query users
    const users = await db.query.users.findMany();
    console.log(`Found ${users.length} users in the database`);
    
    if (users.length > 0) {
      console.log('First user:', users[0]);
    }
    
    console.log('Database connection test successful!');
  } catch (error) {
    console.error('Database test failed:', error);
  }
}

testDb();