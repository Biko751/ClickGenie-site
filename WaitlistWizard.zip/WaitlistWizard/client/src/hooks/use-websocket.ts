import { useState, useEffect, useRef, useCallback } from 'react';

interface WebSocketMessage {
  type: string;
  [key: string]: any;
}

export function useWebSocket() {
  const [isConnected, setIsConnected] = useState(false);
  const [messages, setMessages] = useState<WebSocketMessage[]>([]);
  const websocket = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<number | null>(null);

  // Helper function to get session ID from localStorage
  const getSessionId = useCallback(() => {
    return localStorage.getItem('sessionId');
  }, []);

  // Connect to WebSocket server
  useEffect(() => {
    const connectWebSocket = () => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      console.log('Attempting WebSocket connection to:', wsUrl);
      const socket = new WebSocket(wsUrl);
      
      socket.onopen = () => {
        console.log('WebSocket connection established');
        setIsConnected(true);
        
        // Clear any pending reconnect timeouts
        if (reconnectTimeoutRef.current) {
          window.clearTimeout(reconnectTimeoutRef.current);
          reconnectTimeoutRef.current = null;
        }
      };
      
      socket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          console.log('WebSocket message received:', data);
          setMessages((prev) => [...prev, data]);
        } catch (error) {
          console.error('Failed to parse WebSocket message:', error);
        }
      };
      
      socket.onclose = (event: CloseEvent) => {
        console.log('WebSocket connection closed:', event.code, event.reason);
        setIsConnected(false);
        
        // Try to reconnect after a delay unless the component is unmounting
        if (!event.wasClean) {
          console.log('Attempting to reconnect WebSocket in 3 seconds...');
          reconnectTimeoutRef.current = window.setTimeout(() => {
            connectWebSocket();
          }, 3000);
        }
      };
      
      socket.onerror = (error) => {
        console.error('WebSocket error:', error);
        setIsConnected(false);
      };
      
      websocket.current = socket;
    };

    connectWebSocket();
    
    // Cleanup
    return () => {
      if (websocket.current) {
        websocket.current.close();
        websocket.current = null;
      }
      
      if (reconnectTimeoutRef.current) {
        window.clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = null;
      }
    };
  }, []);

  // Send a message through the WebSocket
  const sendMessage = useCallback((message: WebSocketMessage) => {
    if (websocket.current && websocket.current.readyState === WebSocket.OPEN) {
      const sessionId = getSessionId();
      
      const payload = {
        ...message,
        sessionId
      };
      
      console.log('Sending WebSocket message:', payload);
      websocket.current.send(JSON.stringify(payload));
      return true;
    } else {
      console.warn('WebSocket not connected. Message not sent:', message);
      return false;
    }
  }, [getSessionId]);

  // Clear messages
  const clearMessages = useCallback(() => {
    setMessages([]);
  }, []);

  // Get messages by type
  const getMessagesByType = useCallback((type: string) => {
    return messages.filter(msg => msg.type === type);
  }, [messages]);

  return {
    isConnected,
    messages,
    sendMessage,
    clearMessages,
    getMessagesByType,
  };
}
