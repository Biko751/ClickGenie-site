import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { UserData, getStoredSession, saveSession, clearSession, getCurrentUser, logout } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

interface AuthContextType {
  user: UserData | null;
  sessionId: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (sessionId: string, userData: UserData) => void;
  logout: () => Promise<void>;
  updateUser: (userData: Partial<UserData>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserData | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  // Check for stored session on mount
  useEffect(() => {
    const { sessionId, userData } = getStoredSession();
    
    if (sessionId && userData) {
      setSessionId(sessionId);
      setUser(userData);
      
      // Verify the session is still valid
      getCurrentUser(sessionId)
        .then(updatedUserData => {
          setUser(updatedUserData);
          saveSession(sessionId, updatedUserData);
        })
        .catch(() => {
          // Session expired or invalid
          clearSession();
          setSessionId(null);
          setUser(null);
        })
        .finally(() => {
          setIsLoading(false);
        });
    } else {
      setIsLoading(false);
    }
  }, []);

  const loginUser = (newSessionId: string, userData: UserData) => {
    setSessionId(newSessionId);
    setUser(userData);
    saveSession(newSessionId, userData);
  };

  const logoutUser = async () => {
    if (sessionId) {
      try {
        await logout(sessionId);
      } catch (error) {
        console.error("Logout error:", error);
      }
    }
    
    clearSession();
    setSessionId(null);
    setUser(null);
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    });
  };

  const updateUser = (userData: Partial<UserData>) => {
    if (user) {
      const updatedUser = { ...user, ...userData };
      setUser(updatedUser);
      
      if (sessionId) {
        saveSession(sessionId, updatedUser);
      }
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        sessionId,
        isAuthenticated: !!user && !!sessionId,
        isLoading,
        login: loginUser,
        logout: logoutUser,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
