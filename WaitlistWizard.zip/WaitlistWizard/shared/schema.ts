import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  balance: doublePrecision("balance").notNull().default(0),
  clicksReceived: integer("clicks_received").notNull().default(0),
  clicksGiven: integer("clicks_given").notNull().default(0),
  referralCode: text("referral_code").notNull(),
  referredBy: integer("referred_by"),
  role: text("role").notNull().default("user"), // user or admin
  lastLogin: timestamp("last_login").defaultNow(),
  dailyLoginStreak: integer("daily_login_streak").notNull().default(0),
  lastLoginReward: timestamp("last_login_reward"),
  vipMember: boolean("vip_member").notNull().default(false),
  vipExpiry: timestamp("vip_expiry"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow()
});

export const offers = pgTable("offers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  link: text("link").notNull(),
  network: text("network").notNull(),
  countries: text("countries").notNull(),
  epc: doublePrecision("epc").notNull(),
  maxClicksPerDay: integer("max_clicks_per_day").notNull(),
  description: text("description"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow()
});

export const clicks = pgTable("clicks", {
  id: serial("id").primaryKey(),
  offerId: integer("offer_id").notNull(),
  userId: integer("user_id").notNull(),
  duration: integer("duration"), // Duration in seconds
  verified: boolean("verified").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow()
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amount: doublePrecision("amount").notNull(),
  type: text("type").notNull(), // withdrawal, earning, referral
  status: text("status").notNull().default("completed"),
  description: text("description").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  channel: text("channel").notNull().default("general"),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});

export const withdrawals = pgTable("withdrawals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  transactionId: integer("transaction_id").notNull(),
  amount: doublePrecision("amount").notNull(),
  method: text("method").notNull(), // paypal, bitcoin, bank, etc.
  address: text("address").notNull(), // Email, wallet address, account number, etc.
  status: text("status").notNull().default("pending"), // pending, processing, completed, failed, cancelled
  gatewayId: text("gateway_id"), // ID from payment gateway
  gatewayResponse: jsonb("gateway_response"), // Response from payment gateway
  gatewayData: jsonb("gateway_data"), // Any additional data needed for the gateway
  processedAt: timestamp("processed_at"), // When the withdrawal was processed
  createdAt: timestamp("created_at").defaultNow()
});

// Schemas for data insertion
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  referredBy: true,
});

export const insertOfferSchema = createInsertSchema(offers).pick({
  userId: true,
  title: true,
  link: true,
  network: true,
  countries: true,
  epc: true,
  maxClicksPerDay: true,
  description: true,
});

export const insertClickSchema = createInsertSchema(clicks).pick({
  offerId: true,
  userId: true,
  duration: true,
  verified: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  userId: true,
  amount: true,
  type: true,
  status: true,
  description: true,
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  userId: true,
  channel: true,
  content: true,
});

export const insertWithdrawalSchema = createInsertSchema(withdrawals).pick({
  userId: true,
  transactionId: true,
  amount: true,
  method: true,
  address: true,
  status: true,
  gatewayId: true,
  gatewayResponse: true,
  gatewayData: true,
  processedAt: true,
});

// Types for data retrieval and insertion
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertOffer = z.infer<typeof insertOfferSchema>;
export type Offer = typeof offers.$inferSelect;

export type InsertClick = z.infer<typeof insertClickSchema>;
export type Click = typeof clicks.$inferSelect;

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

export type InsertWithdrawal = z.infer<typeof insertWithdrawalSchema>;
export type Withdrawal = typeof withdrawals.$inferSelect;

// Login schema
export const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

// Register schema with validation
export const registerSchema = insertUserSchema.extend({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  email: z.string().email("Please enter a valid email address"),
  confirmPassword: z.string(),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

// WithdrawSchema
export const withdrawSchema = z.object({
  amount: z.number().min(50, "Minimum withdrawal amount is $50"),
  method: z.enum(["paypal", "crypto"]),
  address: z.string().min(1, "Payment address is required"),
  cryptoNetwork: z.enum(["bitcoin", "usdt"]).optional().refine(val => {
    // CryptoNetwork is required when method is crypto
    return true; // Validation handled in frontend
  }),
  terms: z.boolean().refine(val => val === true, {
    message: "You must agree to the terms",
  }),
});
